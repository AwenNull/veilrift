import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGameState } from '@/lib/stores/useGameState';
import { Circuit } from './Circuit';

// This component only handles the 3D rendering
export function Circuit3D() {
  const groupRef = useRef<THREE.Group>(null);
  const { 
    currentLayer,
  } = useGameState();
  
  // Animate the scene
  useFrame((state) => {
    if (!groupRef.current) return;
    
    // Subtle rotation of the entire circuit
    groupRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 0.1) * 0.03;
    
    // Layer-specific effects
    switch (currentLayer) {
      case 'surface':
        // Slight movement
        groupRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.05;
        break;
      case 'middle':
        // More dynamic movement
        groupRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 0.7) * 0.08;
        groupRef.current.position.x = Math.sin(state.clock.getElapsedTime() * 0.3) * 0.04;
        break;
      case 'deep':
        // Unstable, glitchy movement
        groupRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 1.2) * 0.12;
        groupRef.current.position.x = Math.sin(state.clock.getElapsedTime() * 0.8) * 0.1;
        break;
      case 'core':
        // Chaotic movement
        groupRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 1.5) * 0.15;
        groupRef.current.position.x = Math.sin(state.clock.getElapsedTime() * 1.3) * 0.15;
        break;
    }
  });
  
  return (
    <group ref={groupRef}>
      <Circuit />
    </group>
  );
}

// No longer needed as we're using InterfaceLayer instead

// This component manages the game initialization and 3D rendering
export function GameRenderer() {
  const { 
    initGame,
    gameInitialized
  } = useGameState();
  
  // Initialize game if not already done
  useEffect(() => {
    if (!gameInitialized) {
      console.log("Initializing game state...");
      initGame();
    }
  }, [gameInitialized, initGame]);
  
  // Only return the 3D components for the Canvas
  return <Circuit3D />;
}
