import { useState, useEffect } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { useAudio } from '@/lib/stores/useAudio';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { corruptText } from '@/lib/effects/visualGlitches';
import { getRandomEquation, MetaphysicalEquation } from '@/lib/content/metaphysicalEquations';

export function DecisionNode() {
  const { 
    currentPuzzleIndex, 
    makeDecision, 
    playerPath, 
    revealedRewards,
    addReward,
    currentLayer,
    availablePuzzles,
    narrativeBranches,
    storyFlags
  } = useGameState();
  
  const { playSuccess } = useAudio();
  const [showingReward, setShowingReward] = useState(false);
  const [textRevealProgress, setTextRevealProgress] = useState(0);
  const [decision, setDecision] = useState<string | null>(null);
  const [narrativeContext, setNarrativeContext] = useState<string | null>(null);
  const [metaphysicalEquation, setMetaphysicalEquation] = useState<MetaphysicalEquation | null>(null);
  
  // Make sure we have a valid puzzle index
  const safePuzzleIndex = currentPuzzleIndex % availablePuzzles.length;
  const currentPuzzle = availablePuzzles[safePuzzleIndex];
  
  // Debugging - log when component mounts
  useEffect(() => {
    console.log("DecisionNode mounted");
    console.log("Current puzzle index:", safePuzzleIndex);
    console.log("Current puzzle:", currentPuzzle);
    console.log("Available puzzles:", availablePuzzles.length);
    console.log("Narrative branches:", narrativeBranches.filter(b => b.unlocked).length, "unlocked");
    
    // Check if there's narrative context for this puzzle
    const activeBranches = narrativeBranches.filter(branch => branch.unlocked);
    const activeFlags = storyFlags.filter(flag => flag.active);
    
    // Prepare narrative context if applicable
    if (activeBranches.length > 0 || activeFlags.length > 0) {
      // For now, just note that decisions are having effects
      if (playerPath.length > 3) {
        setNarrativeContext("Your choices are shaping the narrative path.");
      }
      
      // If a specific branch relates to this puzzle, show it
      const relevantBranches = activeBranches.filter(branch => 
        branch.followUpPuzzleIds.includes(currentPuzzle.id)
      );
      
      if (relevantBranches.length > 0) {
        setNarrativeContext(relevantBranches[0].description);
      }
    }
  }, []);
  
  // Clear state when puzzle changes
  useEffect(() => {
    console.log("Puzzle changed to index:", safePuzzleIndex);
    setShowingReward(false);
    setTextRevealProgress(0);
    setDecision(null);
  }, [safePuzzleIndex]);
  
  // Text reveal animation
  useEffect(() => {
    if (textRevealProgress < 1) {
      const timer = setTimeout(() => {
        setTextRevealProgress(prev => Math.min(prev + 0.05, 1));
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [textRevealProgress]);
  
  // Handle decision selection - now with puzzle ID
  const handleDecision = (choice: string) => {
    // Play keyboard sound effect
    try {
      playSuccess();
      console.log("Playing keyboard sound effect");
    } catch (err) {
      console.error("Failed to play sound effect:", err);
    }
    
    setDecision(choice);
    
    // Check if this decision has a reward
    const selectedChoice = currentPuzzle.choices.find(c => c.text === choice);
    
    // Check if this is a philosophical choice that deserves a philosopher portrait
    const isPhilosophical = 
      choice.toLowerCase().includes('ethics') || 
      choice.toLowerCase().includes('philosoph') || 
      choice.toLowerCase().includes('paradox') ||
      choice.toLowerCase().includes('consciousness') ||
      choice.toLowerCase().includes('ontolog') ||
      choice.toLowerCase().includes('logic');
      
    // Always generate a metaphysical equation for rewards
    setMetaphysicalEquation(getRandomEquation());
    
    // Show reward or advance
    if (selectedChoice && selectedChoice.reward) {
      setShowingReward(true);
      addReward(selectedChoice.reward);
    } else {
      // If no reward, just advance after a short delay
      setTimeout(() => {
        makeDecision(choice, currentPuzzle.id);
      }, 1000);
    }
  };
  
  // Continue after showing reward
  const continueAfterReward = () => {
    // Play keyboard sound effect
    try {
      playSuccess();
      console.log("Playing keyboard sound effect");
    } catch (err) {
      console.error("Failed to play sound effect:", err);
    }
    
    setShowingReward(false);
    makeDecision(decision!, currentPuzzle.id);
  };
  
  // Philosopher dismiss function removed as requested
  
  // Handle the case when no puzzle is found
  if (!currentPuzzle) {
    return (
      <div className="fixed inset-0 flex items-center justify-center pointer-events-auto">
        <div className="absolute inset-0 bg-black opacity-80"></div>
        <div className="relative z-10 max-w-lg w-full p-6 border border-white bg-black text-white font-mono">
          <div className="text-xs uppercase text-gray-400">SYSTEM ERROR</div>
          <h2 className="text-xl mt-2">Decision Matrix Corrupted</h2>
          <p className="my-4">Unable to load decision parameters. System returning to default state.</p>
          <Button
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-black w-full"
            onClick={() => makeDecision("System default", "error")}
          >
            RESET AND CONTINUE
          </Button>
        </div>
      </div>
    );
  }
  
  // Calculate what text to show based on the reveal progress
  const displayText = currentPuzzle.text.substring(0, Math.floor(currentPuzzle.text.length * textRevealProgress));
  
  // Get the reward if one is showing
  const rewardToShow = decision ? 
    currentPuzzle.choices.find(c => c.text === decision)?.reward : null;
    
  // Apply glitch effects based on layer
  const glitchLevel = 
    currentLayer === 'surface' ? 0.05 :
    currentLayer === 'middle' ? 0.1 :
    currentLayer === 'deep' ? 0.2 : 0.3;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center pointer-events-auto">
      <div className="absolute inset-0 bg-black opacity-90"></div>
      
      {/* Philosopher portraits removed as requested */}
      
      <div 
        className={cn(
          "relative z-10 max-w-lg w-full mx-4 p-6 border border-gray-700",
          "bg-black text-white font-mono",
          "transition-all duration-500 transform shadow-lg",
          "overflow-hidden",
          (decision && !showingReward) ? "opacity-0 scale-95" : "opacity-100 scale-100"
        )}
      >
        {showingReward ? (
          // Reward display with metaphysical equation
          <div className="flex flex-col">
            <div className="text-xs uppercase text-gray-400 bg-gray-900 px-2 py-1 rounded-sm inline-block mb-3">
              NEW FRAGMENT UNLOCKED
            </div>
            <h2 className="text-xl mb-4 font-light tracking-wide border-b border-gray-800 pb-2">
              {metaphysicalEquation ? metaphysicalEquation.title : rewardToShow}
            </h2>
            
            {/* Metaphysical equation display */}
            <div className="mb-4 p-4 border border-dashed border-gray-700 bg-gray-900 rounded-sm min-h-[120px]">
              {metaphysicalEquation ? (
                <div className="space-y-4">
                  <div className="text-center py-2">
                    <p className="text-lg font-mono tracking-wider">{metaphysicalEquation.equation}</p>
                  </div>
                  <p className="text-sm whitespace-pre-line leading-relaxed text-gray-300">
                    {metaphysicalEquation.explanation}
                  </p>
                </div>
              ) : (
                <p className="text-sm whitespace-pre-line leading-relaxed">
                  {rewardToShow && revealedRewards.find(r => r === rewardToShow)}
                </p>
              )}
            </div>
            
            <Button
              variant="outline"
              className="border-gray-700 text-white hover:bg-white hover:text-black mt-4"
              onClick={continueAfterReward}
            >
              CONTINUE INTO THE CIRCUIT
            </Button>
          </div>
        ) : (
          // Puzzle display
          <div className="flex flex-col">
            <div className="text-xs uppercase text-gray-400 flex justify-between items-center mb-3">
              <span className="bg-gray-900 px-2 py-1 rounded-sm">
                DECISION #{currentPuzzleIndex + 1}
              </span>
              <span className="bg-gray-900 px-2 py-1 rounded-sm">
                LAYER: {currentLayer.toUpperCase()}
              </span>
            </div>
            
            <h2 className="text-xl mb-4 font-light tracking-wide border-b border-gray-800 pb-2">
              {currentLayer === 'core' || Math.random() < 0.2 
                ? corruptText(currentPuzzle.title, glitchLevel * 0.5) 
                : currentPuzzle.title}
            </h2>
            
            {/* Narrative context - shown when player choice has revealed information */}
            {narrativeContext && (
              <div className="mt-1 mb-4 p-2 border border-gray-700 bg-gray-900 bg-opacity-50 rounded-sm">
                <p className="text-xs text-gray-300 italic leading-relaxed">
                  {narrativeContext}
                </p>
              </div>
            )}
            
            <div className="mb-4 overflow-hidden relative">
              <div className="h-1 w-full bg-gray-900 mb-2">
                <div 
                  className="h-full bg-white transition-all" 
                  style={{ width: `${textRevealProgress * 100}%` }}
                ></div>
              </div>
              
              <div className="p-4 border border-gray-800 bg-gray-900 min-h-[150px] max-h-[200px] overflow-y-auto rounded-sm">
                <p className="whitespace-pre-line text-sm leading-relaxed">
                  {currentLayer !== 'surface' && Math.random() < 0.4 
                    ? corruptText(displayText, glitchLevel) 
                    : displayText}
                  {textRevealProgress < 1 && (
                    <span className="animate-pulse">_</span>
                  )}
                </p>
              </div>
            </div>
            
            {textRevealProgress >= 1 && (
              <div className="flex flex-col space-y-2 mt-2">
                {currentPuzzle.choices.map((choice, index) => {
                  // Add glitch effects to choices based on layer depth or add Greek for philosophical choices
                  const isPhilosophical = 
                    choice.text.toLowerCase().includes('ethics') || 
                    choice.text.toLowerCase().includes('philosoph') || 
                    choice.text.toLowerCase().includes('paradox') ||
                    choice.text.toLowerCase().includes('consciousness') ||
                    choice.text.toLowerCase().includes('ontolog');
                  
                  // Greek text for philosophical choices (special severity value 0.42)
                  const displayText = 
                    isPhilosophical && Math.random() < 0.7 ? corruptText(choice.text, 0.42) :
                    currentLayer === 'deep' && Math.random() < 0.3 ? corruptText(choice.text, 0.1) :
                    currentLayer === 'core' ? corruptText(choice.text, 0.15) :
                    choice.text;
                    
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      className={cn(
                        "border-gray-700 text-white hover:bg-white hover:text-black",
                        "text-left px-4 py-3 h-auto justify-start whitespace-normal",
                        "break-words transition-all duration-300",
                        choice.reward && "border-l-2 border-l-gray-500"
                      )}
                      onClick={() => handleDecision(choice.text)}
                    >
                      {displayText}
                    </Button>
                  );
                })}
              </div>
            )}
            
            {/* Show a subtle indicator when there are branching consequences */}
            {playerPath.length > 2 && (
              <div className="mt-4 text-xs text-gray-600 flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-gray-700 mr-2"></span>
                <span>Your choices are shaping the narrative</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
