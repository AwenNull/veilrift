import { useState, useEffect } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { useAudio } from '@/lib/stores/useAudio';
import { Button } from '@/components/ui/button';
import { transmissions } from '@/lib/content/transmissions';
import { cn } from '@/lib/utils';

export function TransmissionDecoder() {
  const { 
    currentTransmissionIndex, 
    completeTransmission,
    currentLayer
  } = useGameState();
  const { playHit, playSuccess } = useAudio();
  
  const [decodedText, setDecodedText] = useState('');
  const [decodingComplete, setDecodingComplete] = useState(false);
  const [decodingProgress, setDecodingProgress] = useState(0);
  const [highlightedSymbols, setHighlightedSymbols] = useState<number[]>([]);
  
  // Make sure we have a valid transmission index
  const safeTransmissionIndex = currentTransmissionIndex % transmissions.length;
  const currentTransmission = transmissions[safeTransmissionIndex];
  
  // Debugging - log when component mounts
  useEffect(() => {
    console.log("TransmissionDecoder mounted");
    console.log("Current transmission index:", safeTransmissionIndex);
    console.log("Current transmission:", currentTransmission);
  }, []);
  
  // Reset state when transmission changes
  useEffect(() => {
    console.log("Transmission changed to index:", safeTransmissionIndex);
    setDecodedText('');
    setDecodingComplete(false);
    setDecodingProgress(0);
    setHighlightedSymbols([]);
  }, [safeTransmissionIndex]);
  
  // Simulate decoding with randomly highlighted symbols
  useEffect(() => {
    if (decodingProgress >= 100) {
      setDecodingComplete(true);
      return;
    }
    
    const decodingTimer = setTimeout(() => {
      // Increment progress
      setDecodingProgress(prev => {
        const increment = Math.random() * 5 + 1; // Random increment for a more natural feel
        return Math.min(prev + increment, 100);
      });
      
      // Update decoded text gradually
      if (currentTransmission) {
        const percentComplete = decodingProgress / 100;
        const textToShow = currentTransmission.content.substring(
          0, 
          Math.floor(currentTransmission.content.length * percentComplete)
        );
        setDecodedText(textToShow);
      }
      
      // Random symbol highlights for visual effect
      const numSymbols = 20;
      const randomSymbols = Array.from(
        { length: Math.floor(Math.random() * 5) + 1 }, 
        () => Math.floor(Math.random() * numSymbols)
      );
      setHighlightedSymbols(randomSymbols);
      
      // Play click sound occasionally
      if (Math.random() < 0.3 && playHit) {
        playHit();
      }
      
    }, 200);
    
    return () => clearTimeout(decodingTimer);
  }, [decodingProgress, currentTransmission, playHit, setDecodingComplete, setDecodedText, setHighlightedSymbols]);
  
  // Play success sound when decoding completes
  useEffect(() => {
    if (decodingComplete && playSuccess) {
      playSuccess();
    }
  }, [decodingComplete, playSuccess]);
  
  // Even if no transmission is found, show something rather than nothing
  // Continue to decision phase
  const handleContinue = () => {
    console.log("Completing transmission, moving to decision phase");
    completeTransmission();
  };
  
  // Fallback if no transmission is found
  if (!currentTransmission) {
    console.log("WARNING: No transmission found at index", currentTransmissionIndex);
    
    return (
      <div className="fixed inset-0 flex items-center justify-center pointer-events-auto">
        <div className="absolute inset-0 bg-black opacity-80"></div>
        <div className="relative z-10 max-w-lg w-full p-6 border border-white bg-black text-white font-mono">
          <div className="text-xs uppercase text-gray-400">SYSTEM ERROR</div>
          <h2 className="text-xl mt-2">Transmission Not Found</h2>
          <p className="my-4">Signal corrupted. Unable to retrieve transmission data.</p>
          <div className="mt-2 text-xs text-red-500">Transmission index: {currentTransmissionIndex}</div>
          <p className="my-2 text-xs">Available transmissions: {transmissions.length}</p>
          <Button
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-black w-full mt-4"
            onClick={handleContinue}
          >
            CONTINUE
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="fixed inset-0 flex items-center justify-center pointer-events-auto">
      <div className="absolute inset-0 bg-black opacity-90"></div>
      
      <div 
        className={cn(
          "relative z-10 max-w-lg w-full mx-4 p-6 border border-gray-700",
          "bg-black text-white font-mono",
          "transition-all duration-500 shadow-lg",
          "overflow-hidden"
        )}
      >
        <div className="text-xs uppercase text-gray-400 flex justify-between items-center mb-3">
          <span className="bg-gray-900 px-2 py-1 rounded-sm">
            TRANSMISSION #{currentTransmissionIndex + 1}
          </span>
          <span className="bg-gray-900 px-2 py-1 rounded-sm">
            LAYER: {currentLayer.toUpperCase()}
          </span>
        </div>
        
        <h2 className="text-xl mb-4 font-light tracking-wide border-b border-gray-800 pb-2">
          {currentTransmission.title}
        </h2>
        
        {/* Decoding progress bar */}
        <div className="mb-4">
          <div className="h-1 w-full bg-gray-900 mb-2">
            <div 
              className="h-full bg-white transition-all" 
              style={{ width: `${decodingProgress}%` }}
            ></div>
          </div>
          
          <div className="text-xs text-gray-400 flex justify-between">
            <span>DECODING PROGRESS</span>
            <span>{Math.floor(decodingProgress)}%</span>
          </div>
        </div>
        
        {/* Symbol grid for visual effect */}
        <div className="grid grid-cols-5 gap-1 mb-4">
          {Array.from({ length: 20 }).map((_, index) => (
            <div 
              key={index}
              className={cn(
                "h-7 w-full flex items-center justify-center text-xs",
                "border border-gray-800 transition-colors",
                highlightedSymbols.includes(index) ? "bg-white text-black" : "bg-transparent text-gray-500"
              )}
            >
              {['0x', '1F', '2D', 'A3', 'B7', 'FF', '00', 'E2', '9C', '7B', 'DE', 'CC', '47', '8A', 'F0', '3E', 'D1', '5C', '6F', '9E'][index]}
            </div>
          ))}
        </div>
        
        {/* Decoded message */}
        <div className="mb-4 p-4 border border-gray-800 bg-gray-900 min-h-[150px] max-h-[200px] overflow-y-auto">
          <p className="whitespace-pre-line text-sm leading-relaxed">
            {decodedText}
            {!decodingComplete && <span className="animate-pulse">_</span>}
          </p>
        </div>
        
        {/* Continue button (only shown when decoding complete) */}
        {decodingComplete && (
          <div className="mt-4">
            <Button
              variant="outline"
              className="border-gray-700 text-white hover:bg-white hover:text-black w-full"
              onClick={handleContinue}
            >
              CONTINUE TO DECISION PHASE
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
