import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Text } from '@react-three/drei';
import * as THREE from 'three';
import { useGameState } from '@/lib/stores/useGameState';
import { useAudio } from '@/lib/stores/useAudio';

// A single circuit node
interface CircuitNodeProps {
  position: [number, number, number];
  size?: number;
  color?: string;
  pulsing?: boolean;
  connected?: boolean;
  onClick?: () => void;
}

function CircuitNode({ 
  position, 
  size = 0.1, 
  color = '#ffffff', 
  pulsing = false,
  connected = false,
  onClick
}: CircuitNodeProps) {
  const ref = useRef<THREE.Mesh>(null);
  const { camera } = useThree();
  const { playHit } = useAudio();
  
  // Pulse animation
  useFrame((state) => {
    if (!ref.current) return;
    
    if (pulsing) {
      const scale = 1 + Math.sin(state.clock.getElapsedTime() * 2) * 0.2;
      ref.current.scale.set(scale, scale, scale);
    }
    
    // Always face the camera
    ref.current.quaternion.copy(camera.quaternion);
  });
  
  const handleClick = () => {
    if (onClick) {
      playHit();
      onClick();
    }
  };
  
  return (
    <group position={position}>
      <mesh 
        ref={ref} 
        onClick={handleClick}
        onPointerOver={() => document.body.style.cursor = 'pointer'}
        onPointerOut={() => document.body.style.cursor = 'default'}
      >
        <planeGeometry args={[size, size]} />
        <meshBasicMaterial 
          color={color} 
          transparent 
          opacity={connected ? 1 : 0.4}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// Circuit line connecting nodes
interface CircuitLineProps {
  start: [number, number, number];
  end: [number, number, number];
  color?: string;
  thickness?: number;
  active?: boolean;
}

function CircuitLine({ 
  start, 
  end, 
  color = '#ffffff',
  thickness = 0.01,
  active = false
}: CircuitLineProps) {
  const ref = useRef<THREE.Line>(null);
  
  useFrame((state) => {
    if (!ref.current || !active) return;
    
    // Create a flowing effect for active lines
    const material = ref.current.material as THREE.LineBasicMaterial;
    const pulse = Math.sin(state.clock.getElapsedTime() * 3) * 0.5 + 0.5;
    material.opacity = 0.3 + pulse * 0.7;
  });
  
  // Create a line between points
  const points = [
    new THREE.Vector3(...start),
    new THREE.Vector3(...end)
  ];
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  
  return (
    <line ref={ref} geometry={geometry}>
      <lineBasicMaterial 
        color={color} 
        transparent 
        opacity={active ? 1 : 0.2} 
        linewidth={thickness}
      />
    </line>
  );
}

// The main circuit component
export function Circuit() {
  const { 
    currentLayer, 
    currentPhase, 
    nodePositions, 
    connections,
    activeNode,
    playerPath,
    advanceToNode
  } = useGameState();
  
  // Generate the circuit visualization
  return (
    <group>
      {/* Draw connections first (as lines) */}
      {connections.map((connection, index) => (
        <CircuitLine 
          key={`line-${index}`}
          start={nodePositions[connection.from]} 
          end={nodePositions[connection.to]}
          active={playerPath.includes(connection.from) && playerPath.includes(connection.to)}
        />
      ))}
      
      {/* Draw nodes */}
      {nodePositions.map((position, index) => {
        // Find connected nodes from the current active node
        const isConnectedToActive = activeNode !== null && 
          connections.some(c => 
            (c.from === activeNode && c.to === index) || 
            (c.to === activeNode && c.from === index)
          );
        
        // Whether this node is interactive now
        const isClickable = isConnectedToActive && !playerPath.includes(index);
        
        // Log node click availability for debugging
        if (isConnectedToActive) {
          console.log(`Node ${index} is connected to active node ${activeNode}, clickable: ${isClickable}`);
        }
        
        const handleNodeClick = () => {
          if (!isClickable) return;
          
          console.log(`Node ${index} clicked`);
          console.log(`Current phase: ${currentPhase}`);
          console.log(`Active node: ${activeNode}`);
          console.log(`Already in path: ${playerPath.includes(index)}`);
          
          // Try to advance to this node
          advanceToNode(index);
        };
        
        return (
          <CircuitNode
            key={`node-${index}`}
            position={position}
            size={index === activeNode ? 0.15 : 0.1}
            color={playerPath.includes(index) ? '#ffffff' : '#888888'}
            pulsing={index === activeNode}
            connected={playerPath.includes(index) || isConnectedToActive}
            onClick={isClickable ? handleNodeClick : undefined}
          />
        );
      })}
      
      {/* Layer indicator */}
      <Text
        position={[0, 2, 0]}
        fontSize={0.15}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`CIRCUIT LAYER: ${currentLayer.toUpperCase()}`}
      </Text>
    </group>
  );
}
