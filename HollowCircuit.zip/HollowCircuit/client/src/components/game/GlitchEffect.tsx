import { useEffect, useRef } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { applyGlitchEffect } from '@/lib/effects/glitch';

export function GlitchEffect() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  const { currentLayer, currentPhase } = useGameState();
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas to full screen
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    resize();
    window.addEventListener('resize', resize);
    
    // Intensity of effects based on the current layer
    let glitchIntensity = 0;
    switch (currentLayer) {
      case 'surface': glitchIntensity = 0.1; break;
      case 'middle': glitchIntensity = 0.25; break;
      case 'deep': glitchIntensity = 0.5; break;
      case 'core': glitchIntensity = 0.7; break;
    }
    
    // Animate the glitch effect
    const animate = () => {
      // Only apply effect if canvas is visible
      if (canvas.width && canvas.height) {
        // Clear the canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Apply glitch effects
        applyGlitchEffect(ctx, canvas.width, canvas.height, glitchIntensity);
      }
      
      // Create intermittent glitches
      if (Math.random() < 0.05) {
        // Temporary more intense glitch
        setTimeout(() => {
          if (canvasRef.current) {
            const tempCtx = canvasRef.current.getContext('2d');
            if (tempCtx) {
              applyGlitchEffect(tempCtx, canvas.width, canvas.height, glitchIntensity * 2);
              
              // Reset after a short time
              setTimeout(() => {
                if (tempCtx) {
                  tempCtx.clearRect(0, 0, canvas.width, canvas.height);
                }
              }, 100);
            }
          }
        }, Math.random() * 2000);
      }
      
      requestRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', resize);
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [currentLayer, currentPhase]);
  
  // Removed random URL generation as requested

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-20"
      style={{ 
        opacity: 0.6, // Increased opacity for more visible glitches
        mixBlendMode: 'lighten' 
      }}
    />
  );
}
