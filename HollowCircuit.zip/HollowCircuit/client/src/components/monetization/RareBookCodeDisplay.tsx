import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { RareBookCode } from '@/lib/monetization/rareBookCodeGenerator';

interface RareBookCodeDisplayProps {
  code: RareBookCode;
  onClose: () => void;
}

/**
 * Component to display a rare book code when a player is lucky enough to win
 * This would appear after reaching certain game depths and winning the random draw
 */
export function RareBookCodeDisplay({ code, onClose }: RareBookCodeDisplayProps) {
  const [isCopied, setIsCopied] = useState(false);
  
  // Format the expiration date
  const formattedExpiration = code.expirationDate.toLocaleDateString("en-US", { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  // Copy code to clipboard
  const copyCodeToClipboard = () => {
    navigator.clipboard.writeText(code.code)
      .then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 3000);
      })
      .catch(err => {
        console.error('Failed to copy code: ', err);
      });
  };

  // Celebration effect
  useEffect(() => {
    // In a full implementation, this would include particle effects,
    // subtle sounds, and other celebratory elements
    document.body.classList.add('celebration-active');
    
    return () => {
      document.body.classList.remove('celebration-active');
    };
  }, []);
  
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-auto">
      <div className="absolute inset-0 bg-black bg-opacity-80"></div>
      
      <div className="relative z-10 max-w-lg w-full mx-4 p-8 border-2 border-yellow-500 bg-black text-white font-mono rounded-sm">
        <div className="text-center mb-6">
          <div className="text-xs uppercase text-yellow-400 tracking-widest mb-1">
            EXTRAORDINARY EVENT
          </div>
          <h2 className="text-2xl font-light tracking-wide text-yellow-300 mb-4">
            You've Been Selected
          </h2>
          
          <div className="w-16 h-1 bg-yellow-500 mx-auto"></div>
        </div>
        
        <p className="mb-4 text-center">
          You have been selected for the opportunity to purchase one of only 10 physical copies of
          "The Hollow Circuit" that will ever be produced.
        </p>
        
        <div className="border border-yellow-700 p-4 bg-black bg-opacity-50 my-6">
          <div className="text-center mb-2 text-sm text-yellow-200">YOUR UNIQUE CODE</div>
          <div className="text-center text-2xl tracking-wider text-yellow-400 font-bold mb-4 break-all">
            {code.code}
          </div>
          
          <div className="flex justify-center">
            <Button 
              variant="outline" 
              className="border-yellow-600 text-yellow-200 hover:bg-yellow-900 hover:text-yellow-100"
              onClick={copyCodeToClipboard}
            >
              {isCopied ? 'Copied!' : 'Copy Code'}
            </Button>
          </div>
        </div>
        
        <div className="text-sm text-gray-400 mb-4">
          <p className="mb-2">To redeem your code:</p>
          <ol className="list-decimal pl-6 space-y-1">
            <li>Visit: <a 
                className="text-yellow-400 underline" 
                href={code.redemptionUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                hollowcircuit.com/redeem
              </a>
            </li>
            <li>Enter your unique code</li>
            <li>Complete the purchase form</li>
            <li>Your rare book will be printed and shipped to you</li>
          </ol>
        </div>
        
        <div className="text-xs text-gray-500 mt-4">
          <p>Code expires: {formattedExpiration}</p>
          <p>This is an extremely rare opportunity (1 in 100,000 players).</p>
        </div>
        
        <div className="mt-6 text-center">
          <Button
            className="bg-yellow-700 hover:bg-yellow-600 text-white"
            onClick={onClose}
          >
            I UNDERSTAND
          </Button>
        </div>
      </div>
    </div>
  );
}