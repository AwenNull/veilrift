import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useGameState } from '@/lib/stores/useGameState';
import { corruptText } from '@/lib/effects/visualGlitches';
import { 
  getRandomMetaComment, 
  getContextualMetaComment, 
  metaCommentaryThemes 
} from '@/lib/content/metaCommentaryData';

interface MetaComment {
  id: string;
  text: string;
  type: 'system' | 'observer' | 'circuit' | 'reflection';
  timestamp: number;
  duration?: number; // How long the comment stays visible
  requiresLayer?: 'surface' | 'middle' | 'deep' | 'core';
  requiresFlag?: string;
  theme?: string; // The philosophical theme this comment belongs to
}

/**
 * A subtle UI component that provides meta-commentary on the player's journey
 * Appearing as disconnected observations, system notes, or philosophical reflections
 */
export function MetaCommentary() {
  const { 
    currentLayer, 
    playerPath, 
    storyFlags,
    currentPuzzleIndex,
    availablePuzzles,
    narrativeBranches
  } = useGameState();
  
  const [comments, setComments] = useState<MetaComment[]>([]);
  const [currentCommentIndex, setCurrentCommentIndex] = useState<number | null>(null);
  
  // Generate system observations based on player actions and context
  useEffect(() => {
    // Show comments from the beginning of the game
    // Always generate a new comment when puzzle changes or every few seconds
    const newComment = generateMetaComment();
    if (newComment) {
      setComments(prev => [...prev.slice(-4), newComment]); // Keep last 5 comments max
      setCurrentCommentIndex(null); // Reset current comment when adding new one
    }
    
    // Add additional comments periodically
    const intervalId = setInterval(() => {
      const additionalComment = generateMetaComment();
      if (additionalComment) {
        setComments(prev => [...prev.slice(-4), additionalComment]);
        // Don't reset index here to avoid disrupting current comment viewing
      }
    }, 20000); // Generate a new one every 20 seconds
    
    return () => clearInterval(intervalId);
  }, [currentPuzzleIndex]);
  
  // Cycle through comments
  useEffect(() => {
    if (comments.length === 0) return;
    
    const intervalId = setInterval(() => {
      setCurrentCommentIndex(prev => {
        if (prev === null) return 0;
        if (prev >= comments.length - 1) return null; // Hide after last comment
        return prev + 1;
      });
    }, 8000); // Show each comment for 8 seconds
    
    return () => clearInterval(intervalId);
  }, [comments]);
  
  // Generate a meta-comment based on current game state
  const generateMetaComment = (): MetaComment | null => {
    // Get current puzzle if available
    const currentPuzzle = availablePuzzles[currentPuzzleIndex % availablePuzzles.length];
    
    // Determine appropriate themes based on game state
    let themeIds: string[] = [];
    
    // Add themes based on current puzzle content
    if (currentPuzzle) {
      if (currentPuzzle.title.toLowerCase().includes('consciousness') || 
          currentPuzzle.text.toLowerCase().includes('consciousness')) {
        themeIds.push('circuit_consciousness');
      }
      
      if (currentPuzzle.title.toLowerCase().includes('reality') || 
          currentPuzzle.text.toLowerCase().includes('reality') ||
          currentPuzzle.text.toLowerCase().includes('perception')) {
        themeIds.push('reality_perception');
      }
      
      if (currentPuzzle.title.toLowerCase().includes('free will') || 
          currentPuzzle.text.toLowerCase().includes('free will') ||
          currentPuzzle.text.toLowerCase().includes('determinism') ||
          currentPuzzle.text.toLowerCase().includes('choice')) {
        themeIds.push('determinism_freedom');
      }
      
      if (currentPuzzle.title.toLowerCase().includes('language') || 
          currentPuzzle.text.toLowerCase().includes('language') ||
          currentPuzzle.text.toLowerCase().includes('meaning') ||
          currentPuzzle.text.toLowerCase().includes('communication')) {
        themeIds.push('language_limits');
      }
      
      if (currentPuzzle.title.toLowerCase().includes('self') || 
          currentPuzzle.text.toLowerCase().includes('recursive') ||
          currentPuzzle.text.toLowerCase().includes('reflection')) {
        themeIds.push('self_reference');
      }
    }
    
    // Add themes based on player progression
    if (playerPath.length > 7) {
      themeIds.push('observer_effect');
    }
    
    if (playerPath.length > 12) {
      themeIds.push('circuit_origins');
    }
    
    if (narrativeBranches.filter(b => b.unlocked).length > 2) {
      themeIds.push('narrative_awareness');
    }
    
    // Always add general themes as fallbacks
    themeIds.push('circuit_consciousness', 'reality_perception');
    
    // Determine comment type based on layer and themes
    let commentType: 'system' | 'observer' | 'circuit' | 'reflection' = 'system';
    
    if (currentLayer === 'surface') {
      commentType = Math.random() < 0.7 ? 'system' : 'observer';
    } else if (currentLayer === 'middle') {
      commentType = Math.random() < 0.5 ? 'system' : 
                    Math.random() < 0.5 ? 'observer' : 'circuit';
    } else if (currentLayer === 'deep') {
      commentType = Math.random() < 0.3 ? 'system' : 
                    Math.random() < 0.4 ? 'circuit' : 'reflection';
    } else {
      // Core layer
      commentType = Math.random() < 0.2 ? 'system' : 
                    Math.random() < 0.3 ? 'circuit' : 'reflection';
    }
    
    // Special contextual cases for specific puzzles
    let commentText: string | null = null;
    
    if (currentPuzzle) {
      // Try to get a contextual comment based on puzzle content
      if (currentPuzzle.title.toLowerCase().includes('consciousness')) {
        commentText = getContextualMetaComment('consciousness_puzzle');
      } else if (currentPuzzle.title.toLowerCase().includes('time')) {
        commentText = getContextualMetaComment('time_puzzle');
      } else if (currentPuzzle.title.toLowerCase().includes('identity') || 
               currentPuzzle.title.toLowerCase().includes('self')) {
        commentText = getContextualMetaComment('identity_puzzle');
      } else if (currentPuzzle.title.toLowerCase().includes('reality')) {
        commentText = getContextualMetaComment('reality_puzzle');
      }
    }
    
    // If no contextual comment, get a themed comment
    if (!commentText) {
      // Select a random theme from our filtered list
      const themeId = themeIds[Math.floor(Math.random() * themeIds.length)];
      commentText = getRandomMetaComment(themeId);
    }
    
    if (!commentText) return null;
    
    // Create the comment object
    return {
      id: `comment_${Date.now()}`,
      text: commentText,
      type: commentType,
      timestamp: Date.now(),
      duration: 8000 + Math.random() * 4000, // 8-12 seconds
      requiresLayer: currentLayer
    };
  };
  
  const getCurrentComment = () => {
    if (currentCommentIndex === null || comments.length === 0) return null;
    return comments[currentCommentIndex];
  };
  
  const currentComment = getCurrentComment();
  
  if (!currentComment) return null;
  
  // Apply style based on comment type
  const getCommentStyle = (type: string) => {
    switch(type) {
      case 'system':
        return "border-l-gray-500 text-gray-300";
      case 'observer':
        return "border-l-blue-800 text-blue-200";
      case 'circuit':
        return "border-l-green-800 text-green-200";
      case 'reflection':
        return "border-l-purple-800 text-purple-200";
      default:
        return "border-l-gray-500 text-gray-300";
    }
  };
  
  const getPrefixByType = (type: string) => {
    switch(type) {
      case 'system':
        return "//";
      case 'observer':
        return "/*";
      case 'circuit':
        return "><";
      case 'reflection':
        return "::";
      default:
        return "//";
    }
  };
  
  // Apply subtle glitch effects based on layer
  const getGlitchLevel = () => {
    switch(currentLayer) {
      case 'surface': return 0.01;
      case 'middle': return 0.05;
      case 'deep': return 0.1;
      case 'core': return 0.15;
      default: return 0;
    }
  };
  
  // Decide if text should be glitched
  const shouldGlitch = () => {
    const baseChance = 
      currentLayer === 'surface' ? 0.1 :
      currentLayer === 'middle' ? 0.2 :
      currentLayer === 'deep' ? 0.3 : 0.4;
      
    return Math.random() < baseChance;
  };
  
  return (
    <div className="fixed bottom-4 left-4 z-40 max-w-xs pointer-events-none transition-opacity duration-500">
      <div 
        className={cn(
          "px-3 py-2 border-l-2 rounded-sm",
          "font-mono text-xs bg-black bg-opacity-70",
          "transition-all duration-700 transform",
          getCommentStyle(currentComment.type)
        )}
      >
        <p className="opacity-60 mb-1">{getPrefixByType(currentComment.type)}</p>
        <p>
          {shouldGlitch() 
            ? corruptText(currentComment.text, getGlitchLevel()) 
            : currentComment.text}
        </p>
      </div>
    </div>
  );
}