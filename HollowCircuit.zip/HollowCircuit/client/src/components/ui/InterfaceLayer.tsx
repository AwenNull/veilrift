import { useEffect, useState } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { TransmissionDecoder } from '../game/TransmissionDecoder';
import { DecisionNode } from '../game/DecisionNode';
import { Button } from './button';
import { MetaCommentary } from './MetaCommentary';
import { useRareBookEligibility } from '@/hooks/useRareBookEligibility';
import { RareBookCodeDisplay } from '../monetization/RareBookCodeDisplay';

/**
 * This component directly renders the game interface without ReactDOM portals
 * It's a simpler approach that avoids React 18 hydration issues
 */
export function InterfaceLayer() {
  const { 
    currentPhase, 
    completeTransmission, 
    makeDecision,
    currentLayer 
  } = useGameState();
  const [renderKey, setRenderKey] = useState(0);
  const [forceVisible, setForceVisible] = useState<string | null>(null);
  
  // Initialize rare book eligibility hooks
  const { 
    winningCode, 
    showCodeModal, 
    closeCodeModal,
    debugGenerateCode 
  } = useRareBookEligibility();
  
  // Force re-render when phase changes to ensure fresh UI
  useEffect(() => {
    console.log("InterfaceLayer detected phase change:", currentPhase);
    setRenderKey(prev => prev + 1);
    setForceVisible(null); // Reset force visible when phase changes naturally
  }, [currentPhase]);
  
  // Debug helpers to force UI elements to show regardless of game state
  const forceShowDecoding = () => {
    console.log("Forcing decoder to show");
    setForceVisible('decoding');
  };
  
  const forceShowDecision = () => {
    console.log("Forcing decision to show");
    setForceVisible('decision');
  };
  
  const forceContinue = () => {
    console.log("Force continuing to next phase");
    if (forceVisible === 'decoding' || currentPhase === 'decoding') {
      completeTransmission();
    } else if (forceVisible === 'decision' || currentPhase === 'decision') {
      makeDecision("Default choice", "system_default");
    }
    setForceVisible(null);
  };
  
  // Determine what to show based on game state or forced visibility
  const showDecoding = forceVisible === 'decoding' || (!forceVisible && currentPhase === 'decoding');
  const showDecision = forceVisible === 'decision' || (!forceVisible && currentPhase === 'decision');
  const showReflection = !forceVisible && currentPhase === 'reflection';
  
  return (
    <div 
      className="fixed inset-0 z-40 pointer-events-none" 
      key={renderKey}
    >
      <div className="absolute top-0 left-0 w-full h-full pointer-events-auto">
        {/* Debug phase indicator - positioned in a better place */}
        <div className="fixed top-4 right-4 bg-black bg-opacity-90 border border-gray-800 px-4 py-2 text-white text-xs z-50 rounded shadow-md">
          <div className="uppercase tracking-widest mb-1 text-gray-400">SYSTEM STATUS</div>
          <div className="mb-2">Current Phase: <span className="text-teal-400">{forceVisible || currentPhase}</span></div>
          
          {/* Debug controls */}
          <div className="flex flex-col gap-1">
            <div className="flex gap-1">
              <Button 
                size="sm" 
                variant="outline" 
                className="text-[10px] h-6 px-2 flex-1"
                onClick={forceShowDecoding}
              >
                Force Decoding
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="text-[10px] h-6 px-2 flex-1"
                onClick={forceShowDecision}
              >
                Force Decision
              </Button>
            </div>
            <div className="flex gap-1 mt-1">
              <Button 
                size="sm" 
                variant="default"
                className="text-[10px] h-6 px-2 flex-1"
                onClick={forceContinue}
              >
                Force Continue
              </Button>
              <Button 
                size="sm" 
                variant="destructive"
                className="text-[10px] h-6 px-2 flex-1"
                onClick={debugGenerateCode}
              >
                Test Rare Book
              </Button>
            </div>
            <div className="text-[8px] opacity-50 mt-1 text-left">
              Layer: {currentLayer} | Debug Mode Active
            </div>
          </div>
        </div>
        
        {/* Meta-commentary layer - always present but controls its own visibility */}
        <MetaCommentary />
        
        {/* Content based on game phase or forced visibility */}
        {showDecoding && (
          <TransmissionDecoder key="decoder" />
        )}
        
        {showDecision && (
          <DecisionNode key="decision" />
        )}
        
        {showReflection && (
          <div className="fixed inset-0">
            <div className="absolute inset-0 bg-black bg-opacity-50"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-center">
              <h2 className="text-xl mb-2">Contemplating...</h2>
              <p className="text-sm opacity-70">Your choice reverberates through the circuit...</p>
            </div>
          </div>
        )}
        
        {/* Rare Book Code Modal - only show when player wins */}
        {showCodeModal && winningCode && (
          <RareBookCodeDisplay 
            code={winningCode} 
            onClose={closeCodeModal}
          />
        )}
      </div>
    </div>
  );
}