import { useState, useEffect } from 'react';
import { Button } from './button';
import { cn } from '@/lib/utils';

interface TutorialStep {
  title: string;
  content: React.ReactNode;
  position?: 'center' | 'top' | 'bottom' | 'left' | 'right';
}

export function TutorialOverlay() {
  const [showTutorial, setShowTutorial] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  const [showHelpButton, setShowHelpButton] = useState(false);
  
  const tutorialSteps: TutorialStep[] = [
    {
      title: "Welcome to Veilrift: Fragments",
      content: (
        <div className="space-y-4">
          <p>
            You find yourself connected to The Hollow Circuit - a network of interconnected consciousness fragments and philosophical puzzles.
          </p>
          <p>
            Your goal is to explore this network by decoding transmissions and making philosophical choices that shape your journey.
          </p>
        </div>
      ),
      position: "center"
    },
    {
      title: "Navigating the Circuit",
      content: (
        <div className="space-y-4">
          <p>
            The network of glowing nodes represents the Circuit. 
            Your current position is shown as the pulsing, brighter node.
          </p>
          <p>
            Click on connected nodes to move through the Circuit. Each movement will lead to a new transmission to decode.
          </p>
        </div>
      ),
      position: "center"
    },
    {
      title: "Decoding Transmissions",
      content: (
        <div className="space-y-4">
          <p>
            As you explore, you'll encounter fragmented transmissions. 
            Wait as they decode to reveal philosophical insights, logs, and communications from those who came before.
          </p>
          <p>
            Once decoding is complete, you can continue to contemplate the meaning.
          </p>
        </div>
      ),
      position: "bottom"
    },
    {
      title: "Making Decisions",
      content: (
        <div className="space-y-4">
          <p>
            After each transmission, you'll be faced with philosophical choices reflecting different perspectives. There are no wrong answers - only different paths.
          </p>
          <p>
            Your choices will guide your journey through different layers of the Circuit: Surface, Middle, Deep, and Core.
          </p>
        </div>
      ),
      position: "bottom"
    },
    {
      title: "Discovering Fragments",
      content: (
        <div className="space-y-4">
          <p>
            Some choices will unlock fragments - poetic texts, philosophical notes, or corrupted memories that provide deeper understanding.
          </p>
          <p>
            These fragments are collected and can be revisited through your journey.
          </p>
        </div>
      ),
      position: "center"
    },
    {
      title: "Begin Your Journey",
      content: (
        <div className="space-y-4">
          <p>
            There is no winning or losing - only exploring and understanding. 
            The meaning you derive from the Circuit is uniquely yours.
          </p>
          <p>
            You can access this tutorial again at any time by clicking the ? button in the corner.
          </p>
        </div>
      ),
      position: "center"
    }
  ];
  
  // Hide tutorial after navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && showTutorial) {
        closeTutorial();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showTutorial]);
  
  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(prevStep => prevStep + 1);
    } else {
      closeTutorial();
    }
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prevStep => prevStep - 1);
    }
  };
  
  const closeTutorial = () => {
    setShowTutorial(false);
    setShowHelpButton(true);
  };
  
  const openTutorial = () => {
    setShowTutorial(true);
    setCurrentStep(0);
  };
  
  if (!showTutorial && !showHelpButton) return null;
  
  return (
    <>
      {showTutorial && (
        <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center transition-opacity">
          <div 
            className={cn(
              "max-w-lg bg-black border border-white p-6 rounded-sm",
              "text-white transition-all duration-500 transform",
            )}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-mono">{tutorialSteps[currentStep].title}</h2>
              <button 
                onClick={closeTutorial}
                className="text-gray-400 hover:text-white"
              >
                ×
              </button>
            </div>
            
            <div className="my-6">
              {tutorialSteps[currentStep].content}
            </div>
            
            <div className="flex justify-between mt-6">
              <Button
                variant="outline" 
                onClick={prevStep}
                disabled={currentStep === 0}
                className="border-white text-white disabled:opacity-30"
              >
                Previous
              </Button>
              
              <div className="flex space-x-1 items-center">
                {tutorialSteps.map((_, index) => (
                  <div 
                    key={index}
                    className={cn(
                      "w-2 h-2 rounded-full",
                      currentStep === index ? "bg-white" : "bg-gray-600"
                    )}
                  />
                ))}
              </div>
              
              <Button 
                variant="outline"
                onClick={nextStep}
                className="border-white text-white hover:bg-white hover:text-black"
              >
                {currentStep < tutorialSteps.length - 1 ? "Next" : "Get Started"}
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {showHelpButton && !showTutorial && (
        <button
          onClick={openTutorial}
          className="fixed bottom-4 right-4 w-10 h-10 bg-black border border-white rounded-full flex items-center justify-center text-white z-40 opacity-70 hover:opacity-100 transition-opacity"
          aria-label="Help"
        >
          ?
        </button>
      )}
    </>
  );
}