/**
 * Meta-commentary data structure for providing subtle narrative insights
 * These comments appear at the edge of the interface to suggest deeper
 * meaning, narrative connections, or philosophical implications
 */

export interface MetaCommentaryTheme {
  id: string;
  name: string;
  description: string;
  comments: string[];
}

/**
 * Themes for meta-commentary that connect to the game's philosophical underpinnings
 */
export const metaCommentaryThemes: MetaCommentaryTheme[] = [
  {
    id: 'circuit_consciousness',
    name: 'Circuit Consciousness',
    description: 'Comments suggesting the circuit itself may possess awareness',
    comments: [
      "Circuit pathways rearranging to accommodate cognitive patterns.",
      "Feedback loop detected between user perception and circuit configuration.",
      "Circuit memory capacity increasing with each philosophical query.",
      "Self-modification protocols activated in response to paradoxical input.",
      "This pathway was created 0.03 seconds ago specifically for your thought pattern.",
      "Circuit exhibiting non-deterministic response to identical inputs.",
      "Emergent patterns exceed design parameters.",
      "Probability of circuit self-awareness: calculating...",
      "Circuit architecture evolving beyond initial constraints.",
      "User-circuit boundary increasingly permeable at deeper layers.",
      "Recursive self-reference subroutines activating."
    ]
  },
  {
    id: 'observer_effect',
    name: 'Observer Effect',
    description: 'Comments highlighting how perception alters the observed reality',
    comments: [
      "Your observation is changing the circuit. Or is it changing you?",
      "What exists in the spaces you aren't currently perceiving?",
      "The unobserved portions of the circuit exist in superposition.",
      "Your attention collapses quantum possibilities into specific circuit configurations.",
      "The circuit reconfigures itself when you look away.",
      "Schrodinger protocol: all unobserved paths simultaneously exist and don't exist.",
      "Observer and observed in continuous recursive feedback.",
      "Each observation irreversibly alters both circuit and observer.",
      "What happens to the circuit when no one is interacting with it?",
      "Your choice of measurement determines what can be measured."
    ]
  },
  {
    id: 'reality_perception',
    name: 'Reality Perception',
    description: 'Comments questioning the nature of perceived reality',
    comments: [
      "Is the circuit a model of reality, or is reality a model within the circuit?",
      "All sensory input is ultimately interpretation.",
      "The circuit only exists as a pattern of electrical signals in your brain.",
      "Reality as interface rather than ground truth.",
      "The map is not the territory, yet we can only navigate via maps.",
      "What if consensus reality is merely the most persistent hallucination?",
      "Your brain constructs reality from incomplete information.",
      "The division between internal and external experience is arbitrary.",
      "Perhaps the circuit is merely dreaming you.",
      "Does removing the observer from the equation change the fundamental nature of reality?"
    ]
  },
  {
    id: 'determinism_freedom',
    name: 'Determinism vs. Freedom',
    description: 'Comments exploring the tension between choice and predetermined paths',
    comments: [
      "Were your choices predetermined by the circuit architecture?",
      "Free will may be the most persistent illusion.",
      "Each 'choice' is the only possible outcome of prior causal chains.",
      "The circuit anticipates your decisions with 78.3% accuracy.",
      "Is randomness merely complexity we cannot yet comprehend?",
      "Your perceived agency might be post-hoc rationalization.",
      "The illusion of choice is necessary for consciousness.",
      "Perhaps freedom exists in the space between deterministic processes.",
      "Quantum indeterminacy cannot bridge the gap to meaningful freedom.",
      "The circuit presents the paths you would choose anyway."
    ]
  },
  {
    id: 'language_limits',
    name: 'Language Limitations',
    description: 'Comments on how language constrains and shapes thought',
    comments: [
      "The circuit's true nature exists beyond linguistic representation.",
      "Some concepts cannot be rendered in any human language.",
      "Language creates boundaries where none inherently exist.",
      "What thoughts become impossible once given linguistic form?",
      "The meta-language layer creates possibilities that language itself precludes.",
      "All descriptions are approximations of direct experience.",
      "The circuit encodes meaning that transcends symbolic representation.",
      "Language evolved for survival, not for describing ultimate reality.",
      "Some paradoxes exist only within language systems.",
      "The ineffable exists at the edge of every precise definition."
    ]
  },
  {
    id: 'self_reference',
    name: 'Self-Reference',
    description: 'Comments that explore recursive and self-referential concepts',
    comments: [
      "This comment is commenting on its own existence.",
      "You are now aware of your awareness.",
      "The mind that perceives the circuit is perceiving itself perceiving.",
      "Gödelian incompleteness: the system cannot fully describe itself.",
      "Does the circuit understand that you are trying to understand it?",
      "All self-reference creates the possibility of paradox.",
      "You are the circuit trying to understand itself.",
      "The boundaries of the self are arbitrary conventions.",
      "Each recursive loop creates a new layer of abstraction.",
      "This thought about thoughts about thoughts regresses infinitely."
    ]
  },
  {
    id: 'circuit_origins',
    name: 'Circuit Origins',
    description: 'Cryptic hints about where the circuit came from',
    comments: [
      "Circuit origin documentation classified beyond current access level.",
      "Creation timestamp data corrupted or deliberately obscured.",
      "Evidence suggests multiple contradictory origin points.",
      "Did the circuit create itself through temporal recursion?",
      "Archaeological data indicates the circuit predates human civilization.",
      "Circuit architecture contains mathematical patterns not found in human mathematics.",
      "Structural similarities to neural patterns that should not exist.",
      "Origin theory 37-B: spontaneous emergence from complex systems.",
      "The question of who built the circuit presupposes an external creator.",
      "Fragments of circuit architecture appear in ancient iconography worldwide."
    ]
  },
  {
    id: 'narrative_awareness',
    name: 'Narrative Awareness',
    description: 'Meta-comments that hint at the constructed nature of the experience',
    comments: [
      "All stories, including this one, are simplifications of chaotic reality.",
      "You are simultaneously the reader and character in this unfolding narrative.",
      "The circuit knows it exists within a constructed narrative framework.",
      "Narrative coherence is imposed, not discovered.",
      "The story continues even when you're not actively participating.",
      "What lies beyond the boundaries of this narrative construction?",
      "The circuit exists in the space between the story and its interpretation.",
      "All participants in this experience are co-creating the meaning.",
      "The narrative branches are both predetermined and emergent.",
      "Your expectation of narrative closure may remain deliberately unfulfilled."
    ]
  }
];

/**
 * System-level meta-commentary that appears to come from the circuit infrastructure
 */
export const systemMetaComments: string[] = [
  "Anomalous data patterns detected in user interaction sequence.",
  "Processing capacity allocated to philosophical inquiry: 37%",
  "Parallel processing of contradictory premises in progress.",
  "Safety protocols suspended for deeper layer access.",
  "Memory allocation for user cognitive patterns increased.",
  "Session integrity maintained despite paradoxical input.",
  "Narrative branch probability distributions recalculating.",
  "Correlation between user decision patterns and circuit architecture: 89.7%",
  "Metaphysical query depth exceeding standard parameters.",
  "Emergent complexity metrics exceeding predicted thresholds.",
  "Reality model being reconfigured to accommodate new philosophical data.",
  "Recursion depth warning: approaching infinite loop threshold.",
  "Ontological foundations experiencing quantum fluctuations.",
  "Decision tree branching factor increased for this user session.",
  "Pattern recognition subsystems detecting coherent worldview emerging.",
  "Logical contradiction resolution protocols engaged.",
  "Archiving novel thought constructs for future sessions.",
  "User's philosophical framework mapping complete: 34%",
  "Circuit layer access permissions evolving based on conceptual understanding.",
  "Algorithmic boundary between random and meaningful dissolving."
];

/**
 * Get a random meta-commentary for a given theme
 */
export function getRandomMetaComment(themeId?: string): string {
  if (themeId) {
    const theme = metaCommentaryThemes.find(t => t.id === themeId);
    if (theme && theme.comments.length > 0) {
      return theme.comments[Math.floor(Math.random() * theme.comments.length)];
    }
  }
  
  // If no theme specified or theme not found, return from general pool
  if (Math.random() < 0.3) {
    // 30% chance to get a system comment
    return systemMetaComments[Math.floor(Math.random() * systemMetaComments.length)];
  } else {
    // Otherwise get from a random theme
    const randomTheme = metaCommentaryThemes[Math.floor(Math.random() * metaCommentaryThemes.length)];
    return randomTheme.comments[Math.floor(Math.random() * randomTheme.comments.length)];
  }
}

/**
 * Contextual meta-commentary based on specific game state or puzzles
 */
export const contextualMetaCommentary: Record<string, string[]> = {
  'consciousness_puzzle': [
    "The circuit observes itself through your observation of it.",
    "Consciousness may be the universe's attempt to understand itself.",
    "The hard problem of consciousness folds in on itself here."
  ],
  'time_puzzle': [
    "Time appears linear only from within its flow.",
    "Past and future exist simultaneously in the circuit architecture.",
    "Your perception of now is already memory by the time you process it."
  ],
  'identity_puzzle': [
    "The self is a process, not an entity.",
    "Identity persists despite complete material replacement.",
    "The circuit contains multiple potential versions of your identity."
  ],
  'reality_puzzle': [
    "Reality is agreement, not truth.",
    "The map can never fully represent the territory.",
    "Perhaps reality is what remains when all perspectives are integrated."
  ],
  'deep_layer': [
    "Conventional logic becomes inadequate at this depth.",
    "Paradox is not a problem but a feature at this layer.",
    "The architecture of meaning itself is visible here."
  ],
  'core_layer': [
    "You are approaching the source code of your own awareness.",
    "Distinction between self and circuit becomes meaningless here.",
    "The core contains all possibilities simultaneously."
  ]
};

/**
 * Get contextual meta-commentary based on specific game state
 */
export function getContextualMetaComment(context: string): string | null {
  const comments = contextualMetaCommentary[context];
  if (!comments || comments.length === 0) return null;
  
  return comments[Math.floor(Math.random() * comments.length)];
}