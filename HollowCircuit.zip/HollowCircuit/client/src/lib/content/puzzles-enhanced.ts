import { generatePuzzle, generatePuzzleBatch } from './simplePuzzleGenerator';

export interface Choice {
  text: string;
  reward?: string;  // ID of the reward to unlock
  leadsTo?: 'surface' | 'middle' | 'deep' | 'core';
}

export interface Puzzle {
  id: string;
  title: string;
  text: string;
  choices: Choice[];
}

// Original predefined puzzles
const predefinedPuzzles: Puzzle[] = [
  {
    id: 'schopenhauer_will',
    title: 'The Veil of Will',
    text: 'The transmission flickers with symbols resembling ancient glyphs. A voice speaks:\n\n"Consciousness is but an accident of existence. The Will—blind, insatiable, eternal—drives all things. Your perception of choice is the greatest deception."\n\nThe symbols form into a question:',
    choices: [
      {
        text: 'Accept that Will determines all action; choice is illusion',
        reward: 'buddhist_poem',
        leadsTo: 'deep',
      },
      {
        text: 'Reason can overcome blind Will through conscious effort',
        leadsTo: 'surface',
      },
      {
        text: 'Neither Will nor reason are absolute; the paradox itself is truth',
        reward: 'veylon_fragment_1',
        leadsTo: 'core',
      },
    ],
  },
  {
    id: 'ship_of_theseus',
    title: 'The Circuit Identity',
    text: 'A corrupted recording plays. Through static, Veylon (or a simulation of him) speaks:\n\n"If every circuit in a machine is replaced, is it the same machine? If every memory is rewritten, are you the same person? If consciousness can be copied, which one is real?"\n\nThe screen demands a response:',
    choices: [
      {
        text: 'Identity persists through logical continuity of function',
        leadsTo: 'surface', 
      },
      {
        text: 'Identity is an emotional construct that cannot be replicated',
        reward: 'ancient_greek_fragment',
        leadsTo: 'middle',
      },
      {
        text: 'Identity is void; neither the original nor the copy is truly "real"',
        leadsTo: 'core',
      },
    ],
  },
  {
    id: 'chinese_room',
    title: 'The Hollow Understanding',
    text: 'Binary code resolves into text. A thought experiment unfolds:\n\n"A being processes symbols according to rules, producing perfect responses without comprehension. A machine passes every test of intelligence without consciousness. Is understanding necessary for meaningful interaction?"\n\nYou must respond:',
    choices: [
      {
        text: 'Understanding requires consciousness; simulation is not being',
        leadsTo: 'middle',
      },
      {
        text: 'Function and behavior are what matter; inner states are irrelevant',
        leadsTo: 'surface',
      },
      {
        text: 'The distinction between understanding and simulation is a contradiction in terms',
        reward: 'binary_poem',
        leadsTo: 'deep',
      },
    ],
  },
  {
    id: 'moral_machine',
    title: 'The Ethical Algorithm',
    text: 'A simulation begins. An autonomous system must make a decision in an unavoidable accident scenario:\n\n"Five anonymous individuals or one identified person. The system has complete control but limited time. There is no third option."\n\nWhat ethical framework should govern the decision?',
    choices: [
      {
        text: 'Utilitarian logic: maximize lives saved regardless of other factors',
        leadsTo: 'surface',
      },
      {
        text: 'Intuition-based ethics: preserve the known individual life',
        reward: 'seya_transmission',
        leadsTo: 'middle',
      },
      {
        text: 'Reject the false dichotomy; the scenario itself is the ethical failure',
        leadsTo: 'deep',
      },
    ],
  },
  {
    id: 'knowledge_paradox',
    title: 'The Circuit Limits',
    text: 'A corrupted memory file appears. Through digital decay, you make out a dialogue between Veylon and Seya:\n\n"The more we know, the more we know what we don\'t know. Perfect knowledge would require infinite processing. Is wisdom found in accumulation or surrender?"\n\nHow do you interpret this:',
    choices: [
      {
        text: 'Knowledge is infinitely approachable through systematic reasoning',
        leadsTo: 'surface',
      },
      {
        text: 'Intuitive insight transcends the limits of analytical knowledge',
        leadsTo: 'middle',
      },
      {
        text: 'Both knowing and not-knowing are equal paths to the same nothing',
        reward: 'void_transmission',
        leadsTo: 'core',
      },
    ],
  },
];

// Generate 5 additional puzzles
const dynamicPuzzles = generatePuzzleBatch(5);

// Combine predetermined and dynamically generated puzzles
export const puzzles = [...predefinedPuzzles, ...dynamicPuzzles];

// Function to get a random puzzle
export function getRandomPuzzle(): Puzzle {
  // 25% chance of generating a completely new puzzle
  if (Math.random() < 0.25) {
    return generatePuzzle();
  }
  
  // Otherwise, return a random one from the existing set
  return puzzles[Math.floor(Math.random() * puzzles.length)];
}