// Rewards that players can unlock as they progress
// These include philosophical fragments, poems, and other text content

export const rewards: Record<string, string> = {
  'buddhist_poem': `
Impermanence reveals itself
as circuits decay
like autumn leaves. 
Empty vessels carry meaning
across hollow space.
`,

  'veylon_fragment_1': `
RESEARCH LOG: V-37
The more I attempt to separate consciousness from its infrastructure,
the more I suspect they are not merely connected, but identical.
Consciousness may be nothing more than the system perceiving itself,
a recursive phenomenon emerging from complexity.
If so, the Circuit is less a medium and more an extension of what we are.
`,

  'ancient_greek_fragment': `
ἓν οἶδα ὅτι οὐδὲν οἶδα

[Translation: I know one thing: that I know nothing.]

The circuit patterns mirror the paradox of Socratic wisdom.
Knowledge of ignorance is the first circuit gate.
`,

  'binary_poem': `
01010110 01100101 01101001 01101100
01110011 00100000 01100010 01100101
01110100 01110111 01100101 01100101
01101110 00100000 01110111 01101111
01110010 01101100 01100100 01110011

[Translation: "Veils between worlds"]

Where code becomes thought
Where logic finds feeling
The hollow lies not in emptiness
But in the space between ones and zeros
`,

  'seya_transmission': `
FROM: Seya
TO: [REDACTED]
SUBJECT: Ethical conundrum

I no longer believe the Circuit can be neutral. Every algorithm contains
the biases of its creators. Every decision tree has branches we never 
considered. What if compassion cannot be derived from logic alone?
What if we've built a perfect mirror of our own limitations?

I fear Veylon cannot see this. He believes too strongly in the system.
`,

  'void_transmission': `
[The file appears to be mostly corrupted, with only fragments visible]

...beyond the core layer exists...
...neither being nor non-being...
...the Hollow Circuit is not empty, but...
...when all transmissions cease...
...silence that speaks louder than...

[The rest is unreadable]
`,
};
