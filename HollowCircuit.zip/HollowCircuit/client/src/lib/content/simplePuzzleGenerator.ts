import { Puzzle, Choice } from './puzzles';

// Philosophical positions
const positions = [
  'Determinism',
  'Free Will',
  'Existentialism',
  'Nihilism',
  'Monism',
  'Dualism',
  'Materialism',
  'Idealism',
  'Skepticism',
  'Empiricism',
  'Rationalism',
  'Pragmatism'
];

// Philosophical topics
const topics = [
  'the nature of consciousness',
  'the meaning of existence',
  'the identity of self over time',
  'the possibility of knowledge',
  'the foundations of ethics',
  'artificial intelligence',
  'the mind-body problem',
  'the existence of free will',
  'the nature of reality',
  'technological progress',
  'the concept of truth',
  'societal evolution'
];

// Question templates
const questionTemplates = [
  'Is %s fundamentally real or an illusion created by our minds?',
  'Can %s be understood through pure reason, or only through experience?',
  'Does %s have objective meaning, or is meaning created subjectively?',
  'Is %s reducible to physical processes, or does it transcend materiality?',
  'How should we approach %s in a world of increasing technological complexity?',
  'Can %s be reconciled with scientific understanding, or are they fundamentally at odds?',
  'What would it mean to truly understand %s?',
  'How does our understanding of %s shape our sense of identity?'
];

// Context templates
const contextTemplates = [
  'The circuit flickers with ancient symbols as you consider a fundamental question.',
  'Data streams converge into a coherent pattern, revealing a philosophical dilemma.',
  'A fragmented transmission from Veylon poses a question that has no simple answer.',
  'The nodes pulse with conflicting information, requiring you to make sense of contradictions.',
  'As you traverse deeper into the circuit, boundaries between concepts begin to blur.',
  'The system presents you with a classic philosophical problem recontextualized for the digital age.',
  'Patterns in the data reveal a recurring theme across multiple layers of reality.'
];

// Response approaches
const approaches = [
  'Rational analysis',
  'Intuitive insight',
  'Dialectical synthesis',
  'Empirical observation',
  'Pragmatic functionality',
  'Transcendent understanding',
  'Quantum interpretation',
  'Phenomenological reduction',
  'Buddhist non-self concept',
  'Transhumanist perspective'
];

/**
 * Generate a random philosophical puzzle
 */
export function generatePuzzle(): Puzzle {
  // Select random elements
  const position = positions[Math.floor(Math.random() * positions.length)];
  const topic = topics[Math.floor(Math.random() * topics.length)];
  const question = questionTemplates[Math.floor(Math.random() * questionTemplates.length)].replace('%s', topic);
  const context = contextTemplates[Math.floor(Math.random() * contextTemplates.length)];
  
  // Create a title
  const title = `${position}: ${topic.charAt(0).toUpperCase() + topic.slice(1)}`;
  
  // Create puzzle text
  const text = `${context}\n\n"${question}"\n\nYou consider your response:`;
  
  // Generate three unique choices
  const usedApproaches: string[] = [];
  const choices: Choice[] = [];
  const layers: ('surface' | 'middle' | 'deep' | 'core')[] = ['surface', 'middle', 'deep', 'core'];
  
  while (choices.length < 3) {
    // Get random approach that hasn't been used yet
    let approach;
    do {
      approach = approaches[Math.floor(Math.random() * approaches.length)];
    } while (usedApproaches.includes(approach));
    usedApproaches.push(approach);
    
    // Create a response based on the approach
    const response = `${approach}: ${generateResponse(approach, topic)}`;
    
    // Random layer assignment
    const layer = layers[Math.floor(Math.random() * layers.length)];
    
    // 33% chance to include a reward
    const hasReward = Math.random() < 0.33;
    const reward = hasReward ? getRandomReward() : undefined;
    
    choices.push({
      text: response,
      leadsTo: layer,
      ...(reward && { reward })
    });
  }
  
  return {
    id: `gen_${position.toLowerCase()}_${Date.now()}`,
    title,
    text,
    choices
  };
}

/**
 * Generate a response for a given approach and topic
 */
function generateResponse(approach: string, topic: string): string {
  switch (approach) {
    case 'Rational analysis':
      return `Through logical deduction, ${topic} can be understood as a structural pattern with predictable properties.`;
    case 'Intuitive insight':
      return `We must look beyond analytical frameworks to grasp ${topic} through direct experiential understanding.`;
    case 'Dialectical synthesis':
      return `The apparent contradictions in ${topic} can be reconciled through higher-order integration of opposites.`;
    case 'Empirical observation':
      return `Only through careful observation and testing can we make valid claims about ${topic}.`;
    case 'Pragmatic functionality':
      return `The truth about ${topic} is whatever concept proves most useful in practice.`;
    case 'Transcendent understanding':
      return `${topic} points beyond itself to truths that cannot be captured in language or logic.`;
    case 'Quantum interpretation':
      return `${topic} exists in superposition of multiple states until consciousness collapses the wavefunction.`;
    case 'Phenomenological reduction':
      return `We must bracket our assumptions about ${topic} to reveal the essential structures of consciousness.`;
    case 'Buddhist non-self concept':
      return `${topic} is empty of inherent existence and arises through interdependent causation.`;
    case 'Transhumanist perspective':
      return `Technological enhancement will transform our understanding of ${topic} beyond current human limitations.`;
    default:
      return `This approach offers a unique perspective on ${topic} that transcends conventional categories.`;
  }
}

/**
 * Get a random reward ID
 */
function getRandomReward(): string {
  const rewards = [
    'buddhist_poem',
    'veylon_fragment_1',
    'ancient_greek_fragment',
    'binary_poem',
    'seya_transmission',
    'void_transmission',
    'circuit_fragment'
  ];
  
  return rewards[Math.floor(Math.random() * rewards.length)];
}

/**
 * Generate a batch of puzzles
 */
export function generatePuzzleBatch(count: number): Puzzle[] {
  const puzzles: Puzzle[] = [];
  for (let i = 0; i < count; i++) {
    puzzles.push(generatePuzzle());
  }
  return puzzles;
}