/**
 * Collection of ASCII art portraits of philosophers
 * Used as rewards for player choices
 */

export interface PhilosopherPortrait {
  name: string;
  era: string;
  ascii: string;
  quote: string;
}

export const philosopherPortraits: PhilosopherPortrait[] = [
  {
    name: "Socrates",
    era: "Classical Greece",
    ascii: `
      .---.
     /     \\
    | o _ o |
    |   ^   |
    |  ===  |
  .-'       '-.
 /             \\
|   SOCRATES    |
|               |
 \\             /
  '-.       .-'
     '-----'
    `,
    quote: "The unexamined life is not worth living."
  },
  {
    name: "Plato",
    era: "Classical Greece",
    ascii: `
       ,---.
      /     \\
     | o   o |
     |   >   |  
     |  ___  |
   .-'       '-.
  /             \\
 |     PLATO     |
 |               |
  \\             /
   '.         .'
     '-.....-'
    `,
    quote: "Reality is created by the mind, we can change our reality by changing our mind."
  },
  {
    name: "Aristotle",
    era: "Classical Greece",
    ascii: `
       .----.
      /      \\
     |  o  o  |
     |   <    |
     |  ----  |
   .-'        '-.
  /              \\
 |   ARISTOTLE    |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "Excellence is never an accident. It is always the result of high intention, sincere effort, and intelligent execution."
  },
  {
    name: "René Descartes",
    era: "Enlightenment",
    ascii: `
       ,-----.
      /       \\
     |  o   o  |
     |    >    |
     |   ---   |
   .-'         '-.
  /               \\
 |    DESCARTES    |
 |                 |
  \\               /
   '.           .'
     '---------'
    `,
    quote: "I think, therefore I am."
  },
  {
    name: "Immanuel Kant",
    era: "Enlightenment",
    ascii: `
       .-----.
      /       \\
     |  o   o  |
     |    ^    |
     |  -----  |
   .-'         '-.
  /               \\
 |      KANT       |
 |                 |
  \\               /
   '.           .'
     '---------'
    `,
    quote: "Act only according to that maxim whereby you can, at the same time, will that it should become a universal law."
  },
  {
    name: "Friedrich Nietzsche",
    era: "Modern",
    ascii: `
       ,---.
      /     \\
     | o _ o |
     |   ^   |
     | ===== |
   .-' ||||| '-.
  /     |||||    \\
 |   NIETZSCHE    |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "He who has a why to live can bear almost any how."
  },
  {
    name: "Simone de Beauvoir",
    era: "Modern",
    ascii: `
       ,----.
      /      \\
     | o   o  |
     |   >    |
     |  ----  |
   .-'        '-.
  /              \\
 |   DE BEAUVOIR  |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "One is not born, but rather becomes, a woman."
  },
  {
    name: "Confucius",
    era: "Ancient China",
    ascii: `
       ,----.
      /      \\
     | o   o  |
     |   >    |
     |  \\___/ |
   .-'        '-.
  /              \\
 |   CONFUCIUS    |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "It does not matter how slowly you go as long as you do not stop."
  },
  {
    name: "Alan Turing",
    era: "Modern",
    ascii: `
       ,----.
      /      \\
     | o   o  |
     |   >    |
     |  ----  |
   .-'        '-.
  /              \\
 |     TURING     |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "We can only see a short distance ahead, but we can see plenty there that needs to be done."
  },
  {
    name: "Hypatia",
    era: "Ancient Alexandria",
    ascii: `
       ,----.
      /      \\
     | o   o  |
     |   >    |
     |  ----  |
   .-'        '-.
  /              \\
 |     HYPATIA    |
 |                |
  \\              /
   '.          .'
     '--------'
    `,
    quote: "Reserve your right to think, for even to think wrongly is better than not to think at all."
  }
];

/**
 * Get a random philosopher portrait
 */
export function getRandomPhilosopher(): PhilosopherPortrait {
  const randomIndex = Math.floor(Math.random() * philosopherPortraits.length);
  return philosopherPortraits[randomIndex];
}

/**
 * Get a specific philosopher by name (case insensitive)
 */
export function getPhilosopherByName(name: string): PhilosopherPortrait | undefined {
  return philosopherPortraits.find(
    p => p.name.toLowerCase() === name.toLowerCase()
  );
}