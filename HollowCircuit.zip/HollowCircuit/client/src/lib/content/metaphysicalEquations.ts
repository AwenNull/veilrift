/**
 * Metaphysical equations that challenge the concept of life and existence
 * Used as rewards in the game
 */

export interface MetaphysicalEquation {
  title: string;
  equation: string;
  explanation: string;
}

export const metaphysicalEquations: MetaphysicalEquation[] = [
  // Additional equations for infinite philosophical content
  {
    title: "Quantum Observer Paradox",
    equation: "Observer ∩ Observed = Reality × P(collapse)",
    explanation: "The intersection of observer and observed creates reality, multiplied by the probability of wavefunction collapse. This suggests that consciousness itself may be the fundamental force that materializes potential into actuality."
  },
  {
    title: "Existential Recursion",
    equation: "Self(t) = Self(t-1) + ∫(Experience) - Entropy",
    explanation: "The self at any moment is equal to the previous self plus integrated experience minus entropy. This implies that identity is neither fixed nor fluid, but rather a recursive function continually redefining itself."
  },
  {
    title: "Moral Superposition",
    equation: "Ethics = ∑(intention₁...ₙ) × ∏(consequence₁...ₙ)",
    explanation: "Ethics exists as the sum of all intentions multiplied by the product of all consequences. This formula suggests that moral value exists in superposition until both intention and consequence are fully realized."
  },
  {
    title: "Phenomenological Boundary",
    equation: "Experience = Reality - ∮(Unknown)",
    explanation: "Experience equals reality minus the closed-loop integral of the unknown. This indicates that what we perceive is always incomplete, bounded by the contours of our ignorance."
  },
  {
    title: "Determinism Function",
    equation: "Choice = Apparent_Freedom ÷ [∑(Past) × ∏(Laws_of_Nature)]",
    explanation: "Choice is merely apparent freedom divided by the product of all past events and natural laws. As our understanding of causation approaches completeness, the illusion of choice approaches zero."
  },
  {
    title: "Information Paradox",
    equation: "Knowledge(t) = Knowledge(t-1) + New_Data - Forgotten + Misunderstood",
    explanation: "Knowledge evolves as a function of previous knowledge plus new data, minus what is forgotten, plus what is misunderstood. This creates an expanding sphere of known unknowns surrounding a contracting core of certainty."
  },
  {
    title: "Existential Calculus",
    equation: "∂(Being)/∂t = Becoming × (1 - Death_Probability)",
    explanation: "The partial derivative of being with respect to time equals becoming multiplied by the complement of death probability. This suggests that existence itself is a continuous differential equation rather than a binary state."
  },
  {
    title: "Meaning Wave Function",
    equation: "Ψ(Meaning) = ∫(Narrative × Values × Connection) dt",
    explanation: "The meaning wave function is the time integral of narrative multiplied by values and connection. When any term approaches zero, meaning collapses into absurdity, requiring a new integration to reestablish coherence."
  },
  {
    title: "Truth Correspondence",
    equation: "Truth = limit[knowledge→∞] (Belief ∩ Reality)",
    explanation: "Truth is the limit, as knowledge approaches infinity, of the intersection between belief and reality. This implies that absolute truth may exist but remains asymptotic—forever approached but never reached by finite minds."
  },
  {
    title: "Conscious Integration",
    equation: "∫(Qualia) = Mind - Φ(Physical_Processes)",
    explanation: "The integral of qualia equals mind minus the physical processes of the brain. This addresses the hard problem of consciousness by quantifying the experiential remainder that physical explanation cannot account for."
  },
  {
    title: "Language Boundary",
    equation: "Communication = Intended - Noise - Ambiguity + Context",
    explanation: "Communication equals what is intended minus noise and ambiguity plus context. As noise approaches zero and context approaches completeness, perfect understanding becomes theoretically possible."
  },
  {
    title: "Freedom Function",
    equation: "Liberty = ∑(Options) - [Constraints × Necessity]",
    explanation: "Liberty equals the sum of all options minus the product of constraints and necessity. When necessity is high, even abundant options yield minimal freedom, revealing the complex interplay between choice and circumstance."
  },
  {
    title: "Existence Paradox",
    equation: "Self = (Being - ∅) ÷ Time",
    explanation: "The self is defined as being minus nothingness, divided by the flow of time. As time approaches infinity, the self approaches zero, suggesting our existence is merely a temporal illusion."
  },
  {
    title: "Consciousness Wave Function",
    equation: "Ψ(consciousness) = ∫(memory × perception) dt",
    explanation: "Consciousness is the integration of memory and perception over time. When memory fails or perception alters, the very nature of our conscious experience transforms fundamentally."
  },
  {
    title: "Existential Identity",
    equation: "I = ∑(choices₁...ₙ) ∩ (∞ - death)",
    explanation: "Identity is the sum of all choices made, intersected with infinite potential minus the finality of death. This suggests that we are both defined by our decisions and constrained by our mortality."
  },
  {
    title: "Reality Equilibrium",
    equation: "R = [subjective × P(belief)] + [objective × (1-P(belief))]",
    explanation: "Reality exists in equilibrium between the subjective (weighted by probability of belief) and the objective (weighted by probability of disbelief). As belief approaches certainty, reality becomes increasingly subjective."
  },
  {
    title: "The Meaning Function",
    equation: "M(life) = purpose ÷ absurdity",
    explanation: "Meaning is derived from the ratio of purpose to absurdity. When absurdity approaches infinity, meaning approaches zero, suggesting that in an absurd universe, purpose must be self-created."
  },
  {
    title: "Ethics Transformation",
    equation: "∮(intention) + ∑(consequences) = moral_weight",
    explanation: "The moral weight of an action is the closed-loop integral of intentions plus the sum of all consequences. This demonstrates the tension between deontological and consequentialist ethics."
  },
  {
    title: "Free Will Uncertainty",
    equation: "W = decision - ∑(causation) ± randomness",
    explanation: "Free will is what remains of a decision after all causal factors are accounted for, with an uncertainty principle of randomness. As our understanding of causation increases, the domain of free will potentially shrinks."
  },
  {
    title: "Veylon Discontinuity",
    equation: "V = lim(t→∞) [knowledge ÷ (mystery × complexity)]",
    explanation: "The Veylon Discontinuity represents the limit of knowledge divided by the product of mystery and complexity as time approaches infinity. It suggests that complete understanding is asymptotic—forever approached but never reached."
  },
  {
    title: "Perception Horizon",
    equation: "P = reality - bias(observer) - limit(senses)",
    explanation: "Perception equals reality minus observer bias minus sensory limitations. This equation reveals that true objective reality may be permanently inaccessible to any conscious entity due to inherent constraints."
  },
  {
    title: "Temporal Recursion",
    equation: "Now = ∫(memory) + d/dt(anticipation)",
    explanation: "The present moment is the integration of all memories plus the rate of change of anticipation. This suggests that 'now' is neither objective nor fixed but a constantly shifting frame between past and future."
  }
];

/**
 * Get a random metaphysical equation
 */
export function getRandomEquation(): MetaphysicalEquation {
  const randomIndex = Math.floor(Math.random() * metaphysicalEquations.length);
  return metaphysicalEquations[randomIndex];
}