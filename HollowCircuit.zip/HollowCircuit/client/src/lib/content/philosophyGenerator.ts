import { transmissions } from './transmissions';
import { rewards } from './rewards';
import { Puzzle, Choice } from './puzzles';

/**
 * Philosophical debate elements for procedural generation
 */

// Base philosophical positions
const philosophicalPositions = [
  {
    name: 'Determinism',
    description: 'The belief that all events are determined by causes external to the will',
    examples: [
      'everything that happens is the only possible thing that could happen',
      'free will is merely an illusion',
      'all choices are predetermined by prior causes',
      'consciousness is merely witnessing what must unfold'
    ]
  },
  {
    name: 'Existentialism',
    description: 'A philosophy emphasizing individual existence, freedom and choice',
    examples: [
      'existence precedes essence',
      'we are defined by our choices, not our nature',
      'meaning must be created through authentic lived experience',
      'we are condemned to be free'
    ]
  },
  {
    name: 'Nihilism',
    description: 'The rejection of all religious and moral principles',
    examples: [
      'existence is without objective meaning or purpose',
      'there are no inherent moral values',
      'truth itself is a social construct with no objective basis',
      'consciousness is an evolutionary accident'
    ]
  },
  {
    name: 'Rationalism',
    description: 'The practice of basing opinions and actions on reason rather than emotion',
    examples: [
      'reason alone can discover truths about the world',
      'mathematical logic provides the clearest path to knowledge',
      'emotions cloud judgment and create biased perspectives',
      'objective understanding requires detachment from subjective experience'
    ]
  },
  {
    name: 'Empiricism',
    description: 'The theory that all knowledge is derived from experience',
    examples: [
      'all knowledge comes from sensory experience',
      'abstract concepts are merely generalizations from specific examples',
      'we can only understand what we can observe',
      'pure reason without evidence leads to unfounded speculation'
    ]
  },
  {
    name: 'Dualism',
    description: 'The division of something into two opposed or contrasted aspects',
    examples: [
      'mind and body are fundamentally different kinds of things',
      'consciousness cannot be reduced to physical processes',
      'subjective experience exists in a different domain than objective reality',
      'the physical and the spiritual occupy separate realms'
    ]
  },
  {
    name: 'Monism',
    description: 'A theory that denies the duality of matter and mind',
    examples: [
      'all phenomena can be explained in terms of a single reality',
      'mind and matter are aspects of the same underlying substance',
      'consciousness emerges from physical processes without being separate from them',
      'the apparent distinction between subject and object is illusory'
    ]
  },
  {
    name: 'Skepticism',
    description: 'A questioning attitude toward knowledge, facts, or opinions',
    examples: [
      'we should suspend judgment on all beliefs',
      'certain knowledge is impossible',
      'questioning is more valuable than believing',
      'doubt is the beginning of wisdom'
    ]
  },
];

// Philosophical questions
const philosophicalQuestions = [
  {
    question: 'What is the nature of consciousness?',
    context: 'As the circuit processes your signal, a fundamental question arises about the nature of your own awareness.',
    variations: [
      'Is consciousness an emergent property or a fundamental aspect of reality?',
      'Can consciousness exist independent of physical form?',
      'Is your sense of self a unified entity or a collection of processes?',
      'Would a perfect simulation of a mind actually be conscious?'
    ]
  },
  {
    question: 'Does free will exist?',
    context: 'The branching pathways of the circuit mirror the choices in your own life.',
    variations: [
      'Are your choices predetermined or genuinely free?',
      'Can deterministic processes give rise to true choice?',
      'Is choice possible in a universe governed by cause and effect?',
      'Does quantum indeterminacy allow for free will?'
    ]
  },
  {
    question: 'What is the relationship between mind and reality?',
    context: 'As you traverse deeper into the circuit, the boundary between your thoughts and the environment begins to blur.',
    variations: [
      'Does reality exist independent of minds perceiving it?',
      'Is perception a direct connection to reality or a constructed model?',
      'Can we trust our senses to reveal what is truly real?',
      'Are mathematical structures more real than physical objects?'
    ]
  },
  {
    question: 'What constitutes personal identity over time?',
    context: 'The circuit preserves traces of those who came before. What part of you remains constant?',
    variations: [
      'If your memories were transferred to another body, would that still be you?',
      'Is consciousness continuous or a series of discrete moments?',
      'What makes you the same person you were ten years ago?',
      'If your mind were perfectly copied, which would be the real you?'
    ]
  },
  {
    question: 'How should we approach moral dilemmas?',
    context: 'The circuit responds differently based on the ethical frameworks you bring to it.',
    variations: [
      'Should actions be judged by their intentions or their consequences?',
      'Are moral truths objective or subjective?',
      'Does moral responsibility require free will?',
      'Can algorithms make ethical decisions?'
    ]
  },
  {
    question: 'What is the meaning of existence?',
    context: 'Echoes of purpose and nihilism resonate through the circuit pathways.',
    variations: [
      'Is meaning something we discover or something we create?',
      'Can life have purpose in an indifferent universe?',
      'Is suffering necessary for meaningful existence?',
      'Would eternal life eventually become meaningless?'
    ]
  },
];

// Theoretical frameworks
const theoreticalFrameworks = [
  {
    name: 'Buddhist non-self concept',
    description: 'The notion that there is no unchanging, permanent self, soul, or essence',
    approach: [
      'the self is a collection of changing processes rather than a fixed entity',
      'consciousness arises from interdependent conditions',
      'attachment to the concept of self leads to suffering',
      'recognizing emptiness (śūnyatā) as the nature of all phenomena'
    ]
  },
  {
    name: 'Kantian transcendental idealism',
    description: 'The view that we can have knowledge of objects only as they appear to us, not as they are in themselves',
    approach: [
      'the structures of the mind shape all experience',
      'space and time are forms of intuition rather than features of external reality',
      'the thing-in-itself remains fundamentally unknowable',
      'synthetic a priori knowledge as the foundation of understanding'
    ]
  },
  {
    name: 'Hegelian dialectic',
    description: 'The development of ideas in a dialectical process from thesis to antithesis to synthesis',
    approach: [
      'contradiction drives the evolution of concepts and consciousness',
      'history unfolds as the progression of Spirit coming to know itself',
      'apparent opposites contain elements of each other',
      'the Absolute reveals itself through historical development'
    ]
  },
  {
    name: 'Daoist wu-wei',
    description: 'The concept of "non-action" or "effortless action" in harmony with nature',
    approach: [
      'acting in accordance with the natural flow rather than against it',
      'embracing paradox rather than resolving it',
      'finding power in yielding rather than forcing',
      'the unnamed Dao as the origin of all things'
    ]
  },
  {
    name: 'AI consciousness theory',
    description: 'Theoretical frameworks addressing whether artificial systems can possess consciousness',
    approach: [
      'consciousness as an emergent property of complex information processing',
      'the integrated information theory approach to measuring awareness',
      'distinguishing between simulated and genuine understanding',
      'the Chinese Room argument against computational consciousness'
    ]
  },
  {
    name: 'Quantum mind theory',
    description: 'Models of consciousness that involve quantum mechanical phenomena',
    approach: [
      'quantum coherence in neural microtubules as the basis of consciousness',
      'the observer effect suggesting mind-matter interaction',
      'non-local entanglement as a model for unified awareness',
      'quantum indeterminacy providing a physical basis for free will'
    ]
  },
  {
    name: 'Transhumanist perspective',
    description: 'The belief that humans can and should transcend current limitations through technology',
    approach: [
      'mind uploading as a path to extended consciousness',
      'the technological singularity as an evolutionary transition',
      'intelligence enhancement as a moral imperative',
      'virtual reality as a legitimate extension of human experience'
    ]
  },
  {
    name: 'Phenomenological reduction',
    description: 'Husserls method of suspending judgment about the natural world to analyze experience',
    approach: [
      'bracketing assumptions to reveal the structure of consciousness',
      'the intentionality of consciousness always directed toward objects',
      'the lifeworld as the foundation of all theoretical attitudes',
      'intersubjectivity as necessary for objective knowledge'
    ]
  },
];

// Response options for philosophical questions
const responseTypes = [
  {
    type: 'Rational',
    style: 'A logical analysis based on deductive reasoning',
    examples: [
      'Applying formal logic to examine the premises and conclusions',
      'Analyzing the internal consistency of the position',
      'Breaking down complex questions into simpler components',
      'Seeking universal principles that apply across contexts'
    ]
  },
  {
    type: 'Intuitive',
    style: 'An approach based on direct insight rather than analytical reasoning',
    examples: [
      'Trusting immediate perception over abstract analysis',
      'Recognizing patterns without explicit logical steps',
      'Drawing on emotional and bodily responses',
      'Valuing personal revelation over conventional knowledge'
    ]
  },
  {
    type: 'Pragmatic',
    style: 'Judging ideas by their practical consequences and utility',
    examples: [
      'Asking what difference an idea makes in practice',
      'Valuing workable solutions over theoretical elegance',
      'Testing concepts through their application in real situations',
      'Focusing on outcomes rather than abstract principles'
    ]
  },
  {
    type: 'Skeptical',
    style: 'Systematically questioning assumptions and claims to knowledge',
    examples: [
      'Suspending judgment in the absence of sufficient evidence',
      'Identifying potential sources of error or bias',
      'Examining the foundations of what seems obvious',
      'Questioning whether certainty is possible'
    ]
  },
  {
    type: 'Dialectical',
    style: 'Exploring contradictions to reach higher understanding',
    examples: [
      'Finding the partial truth in opposing positions',
      'Moving through thesis, antithesis, and synthesis',
      'Recognizing the unity of apparent opposites',
      'Using contradiction as a guide to deeper insight'
    ]
  },
  {
    type: 'Mystical',
    style: 'Pointing to direct experience beyond conceptual understanding',
    examples: [
      'Recognizing the limitations of language and concepts',
      'Embracing paradox rather than resolving it',
      'Valuing direct experience over theoretical knowledge',
      'Pointing to what lies beyond rational comprehension'
    ]
  },
];

// Implications of philosophical positions
const philosophicalImplications = [
  {
    domain: 'Ethics',
    questions: [
      'Does this position allow for moral responsibility?',
      'How does this view affect our treatment of others?',
      'Does this framework provide a basis for ethical decisions?',
      'Can moral claims have objective validity under this view?'
    ]
  },
  {
    domain: 'Science',
    questions: [
      'How does this perspective relate to scientific methodology?',
      'Does this view account for the success of scientific theories?',
      'Can scientific discoveries inform this philosophical position?',
      'What are the limits of scientific knowledge according to this view?'
    ]
  },
  {
    domain: 'Social Structures',
    questions: [
      'What kind of society would emerge from widespread adoption of this view?',
      'How does this position affect our understanding of political authority?',
      'Does this perspective promote certain social arrangements over others?',
      'How might this view change our economic institutions?'
    ]
  },
  {
    domain: 'Personal Identity',
    questions: [
      'How does this position affect our sense of self?',
      'Does this view change how we relate to our past and future?',
      'What implications does this have for personal transformation?',
      'How might this perspective alter our relationship with death?'
    ]
  },
  {
    domain: 'Technology',
    questions: [
      'How does this view inform our approach to artificial intelligence?',
      'What implications does this have for mind uploading or consciousness transfer?',
      'Does this perspective suggest ethical guidelines for technological development?',
      'How might advanced technology challenge or support this philosophical position?'
    ]
  },
];

/**
 * Generate a random philosophical puzzle with multiple choices
 * Each choice leads to a different circuit layer and may unlock a reward
 */
export function generatePhilosophicalPuzzle(): Puzzle {
  // Select random components with greater variety
  const allPositions = [...philosophicalPositions, ...additionalPhilosophicalApproaches];
  const allQuestions = [...philosophicalQuestions, ...expandedPhilosophicalQuestions];
  
  const position = allPositions[Math.floor(Math.random() * allPositions.length)];
  const question = allQuestions[Math.floor(Math.random() * allQuestions.length)];
  const framework = theoreticalFrameworks[Math.floor(Math.random() * theoreticalFrameworks.length)];
  
  // Generate question variation
  const questionVariation = question.variations[Math.floor(Math.random() * question.variations.length)];
  
  // Generate a unique ID with timestamp to ensure uniqueness
  const id = `philosophical_${position.name.toLowerCase()}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
  
  // Generate varied title formats
  let title;
  const titleFormat = Math.floor(Math.random() * 4);
  
  if (titleFormat === 0) {
    title = `${position.name}: ${question.question}`;
  } else if (titleFormat === 1) {
    title = `On ${question.question.toLowerCase()}`;
  } else if (titleFormat === 2) {
    title = `${framework.name} and ${question.question}`;
  } else {
    title = `The ${position.name} Perspective: ${question.question}`;
  }
  
  // Generate more varied main text formats
  let text;
  const textFormat = Math.floor(Math.random() * 3);
  
  if (textFormat === 0) {
    text = `${question.context}\n\n${framework.name} suggests that ${framework.approach[Math.floor(Math.random() * framework.approach.length)]}.\n\n${questionVariation}`;
  } else if (textFormat === 1) {
    text = `As you navigate through the circuit, a question emerges:\n\n${questionVariation}\n\nFrom the perspective of ${framework.name}, ${framework.approach[Math.floor(Math.random() * framework.approach.length)]}.\n\n${question.context}`;
  } else {
    text = `${questionVariation}\n\nThis question arises as ${question.context.toLowerCase()}\n\nConsider how ${framework.name} might address this: ${framework.approach[Math.floor(Math.random() * framework.approach.length)]}.`;
  }
  
  // Generate more diverse choices using different response types and implications
  const choices: Choice[] = [];
  
  // Shuffle response types and implications for more variety
  const shuffledResponseTypes = [...responseTypes].sort(() => Math.random() - 0.5);
  const shuffledImplications = [...philosophicalImplications].sort(() => Math.random() - 0.5);
  
  // Select a subset to use (3-4 choices)
  const numChoices = 3 + Math.floor(Math.random() * 2); // 3 or 4 choices
  const selectedResponseTypes = shuffledResponseTypes.slice(0, numChoices);
  
  // Generate a choice for each selected response type
  selectedResponseTypes.forEach((responseType, index) => {
    const implication = shuffledImplications[index % shuffledImplications.length];
    
    // Create more varied choice text formats
    let choiceText;
    const choiceFormat = Math.floor(Math.random() * 3);
    
    if (choiceFormat === 0) {
      choiceText = `${responseType.type} approach: ${responseType.examples[Math.floor(Math.random() * responseType.examples.length)]}`;
    } else if (choiceFormat === 1) {
      choiceText = `${responseType.examples[Math.floor(Math.random() * responseType.examples.length)]} (${responseType.type})`;
    } else {
      const implQuestion = implication.questions[Math.floor(Math.random() * implication.questions.length)];
      choiceText = `Consider ${implQuestion.toLowerCase()} through a ${responseType.type.toLowerCase()} lens`;
    }
    
    // Determine which layer this choice leads to
    let leadsTo: 'surface' | 'middle' | 'deep' | 'core';
    if (responseType.type === 'Rational' || responseType.type === 'Pragmatic') {
      leadsTo = 'surface';
    } else if (responseType.type === 'Intuitive' || responseType.type === 'Skeptical') {
      leadsTo = 'middle';
    } else if (responseType.type === 'Dialectical') {
      leadsTo = 'deep';
    } else {
      leadsTo = 'core';
    }
    
    // Chance to add a reward (33%)
    const hasReward = Math.random() < 0.33;
    
    // Get available reward IDs
    const rewardIds = Object.keys(rewards);
    const randomRewardId = rewardIds[Math.floor(Math.random() * rewardIds.length)];
    
    choices.push({
      text: choiceText,
      leadsTo,
      ...(hasReward && { reward: randomRewardId })
    });
  });
  
  return {
    id,
    title,
    text,
    choices
  };
}

/**
 * Generate a batch of philosophical puzzles
 */
/**
 * Additional philosophical approaches to provide infinite variety
 */
const additionalPhilosophicalApproaches = [
  {
    name: 'Absurdism',
    description: 'The conflict between human desire for meaning and the universe\'s lack of it',
    examples: [
      'embracing the inherent meaninglessness of existence',
      'finding value in the pursuit of meaning despite its impossibility',
      'accepting the absurd condition without escaping through faith or suicide',
      'authentic living through confrontation with absurdity'
    ]
  },
  {
    name: 'Panpsychism',
    description: 'The view that consciousness is fundamental and ubiquitous',
    examples: [
      'consciousness as an intrinsic property of all things',
      'mind as a fundamental aspect of reality, not an emergent property',
      'subjective experience existing at all levels of organization',
      'bridging the explanatory gap between mind and matter'
    ]
  },
  {
    name: 'Solipsism',
    description: 'The philosophical idea that only one\'s mind is sure to exist',
    examples: [
      'the self as the only verifiable existence',
      'other minds as possibly illusory constructs',
      'the external world as potentially a projection of consciousness',
      'knowledge being limited to one\'s own mental states'
    ]
  },
  {
    name: 'Process Philosophy',
    description: 'The view that process, rather than substance, is fundamental',
    examples: [
      'reality as fundamentally dynamic and ever-changing',
      'entities as events and processes rather than static objects',
      'relationships defining entities more than intrinsic properties',
      'the present moment as a creative synthesis of past and future'
    ]
  },
  {
    name: 'Perspectivism',
    description: 'The view that interpretation is essential to the meaning of all experiences',
    examples: [
      'truth as dependent on perspective and interpretation',
      'knowledge claims as expressions of a particular viewpoint',
      'objectivity as the integration of multiple perspectives',
      'no single correct way of seeing the world'
    ]
  },
  {
    name: 'Posthumanism',
    description: 'Philosophy exploring the boundaries of humanity and technology',
    examples: [
      'dissolving the traditional boundaries between human and non-human',
      'challenging anthropocentrism in philosophical thought',
      'embracing hybrid identities across biological and technological domains',
      'reconceptualizing humanity in light of technological transformation'
    ]
  }
];

/**
 * Additional philosophical questions to expand variety
 */
const expandedPhilosophicalQuestions = [
  {
    question: 'What is the relationship between language and reality?',
    context: 'The symbols within the circuit form patterns that challenge your understanding of communication.',
    variations: [
      'Does language create reality or merely describe it?',
      'Can we think thoughts that cannot be expressed in language?',
      'Are there truths that exist beyond linguistic representation?',
      'How do metaphors shape our conceptual understanding?'
    ]
  },
  {
    question: 'What is the nature of time?',
    context: 'As you move through the circuit, temporal distortions alter your perception of past and future.',
    variations: [
      'Is time a fundamental aspect of reality or simply a human construct?',
      'Does the present moment have duration, or is it merely a boundary?',
      'Could the future already exist in some sense?',
      'Is the flow of time an illusion of consciousness?'
    ]
  },
  {
    question: 'What constitutes genuine knowledge?',
    context: 'The circuit contains information, but distinguishing knowledge from data proves challenging.',
    variations: [
      'Is knowledge justified true belief, or something more?',
      'Can we know something without being able to express it?',
      'Is certainty a requirement for knowledge?',
      'How should we approach the limits of human understanding?'
    ]
  },
  {
    question: 'What is the relationship between mind and body?',
    context: 'Your physical form remains still while your mind traverses the circuit\'s pathways.',
    variations: [
      'Could consciousness exist without a physical substrate?',
      'Is the mind reducible to brain processes?',
      'How does embodiment shape cognitive experience?',
      'What does the possibility of uploading consciousness imply?'
    ]
  },
  {
    question: 'Do numbers and mathematical objects exist independently of minds?',
    context: 'The mathematical patterns in the circuit seem to transcend their physical implementation.',
    variations: [
      'Are mathematical truths discovered or invented?',
      'Why is mathematics so effective at describing physical reality?',
      'Do abstract objects have a form of existence?',
      'Is mathematics the language of reality itself?'
    ]
  }
];

/**
 * Generate a larger batch of philosophical puzzles to provide more variety
 */
export function generatePhilosophicalPuzzleBatch(count: number): Puzzle[] {
  // Combine original and additional philosophical content
  const allPositions = [...philosophicalPositions, ...additionalPhilosophicalApproaches];
  const allQuestions = [...philosophicalQuestions, ...expandedPhilosophicalQuestions];
  
  const puzzles: Puzzle[] = [];
  for (let i = 0; i < count; i++) {
    // Select random components from expanded pool
    const position = allPositions[Math.floor(Math.random() * allPositions.length)];
    const question = allQuestions[Math.floor(Math.random() * allQuestions.length)];
    const framework = theoreticalFrameworks[Math.floor(Math.random() * theoreticalFrameworks.length)];
    
    // Generate question variation
    const questionVariation = question.variations[Math.floor(Math.random() * question.variations.length)];
    
    // Generate a unique ID
    const id = `philosophical_${position.name.toLowerCase()}_${Date.now() + i}`;
    
    // Generate title combining position and question
    const title = `${position.name}: ${question.question}`;
    
    // Generate the main text with more philosophical depth
    const text = `${question.context}\n\n${framework.name} suggests that ${framework.approach[Math.floor(Math.random() * framework.approach.length)]}.\n\n${questionVariation}\n\nConsider how ${position.name.toLowerCase()} might approach this question.`;
    
    // Generate more varied philosophical choices
    const choices: Choice[] = [];
    
    // Shuffle response types to use
    const shuffledResponseTypes = [...responseTypes].sort(() => Math.random() - 0.5).slice(0, 4);
    
    // Generate a choice for each response type with more philosophical content
    shuffledResponseTypes.forEach((responseType, index) => {
      const implication = philosophicalImplications[Math.floor(Math.random() * philosophicalImplications.length)];
      
      // Create more detailed choice text
      const choiceText = `${responseType.type} approach: ${responseType.examples[Math.floor(Math.random() * responseType.examples.length)]} Consider ${implication.domain.toLowerCase()}: ${implication.questions[Math.floor(Math.random() * implication.questions.length)]}`;
      
      // Determine which layer this choice leads to
      let leadsTo: 'surface' | 'middle' | 'deep' | 'core';
      if (responseType.type === 'Rational' || responseType.type === 'Pragmatic') {
        leadsTo = 'surface';
      } else if (responseType.type === 'Intuitive' || responseType.type === 'Skeptical') {
        leadsTo = 'middle';
      } else if (responseType.type === 'Dialectical') {
        leadsTo = 'deep';
      } else {
        leadsTo = 'core';
      }
      
      // Random chance to unlock a reward
      const hasReward = Math.random() < 0.3;
      const rewardId = hasReward ? `philosophical_insight_${Math.floor(Math.random() * 10)}` : undefined;
      
      choices.push({
        text: choiceText,
        leadsTo,
        reward: rewardId
      });
    });
    
    puzzles.push({
      id,
      title,
      text,
      choices
    });
  }
  
  return puzzles;
}