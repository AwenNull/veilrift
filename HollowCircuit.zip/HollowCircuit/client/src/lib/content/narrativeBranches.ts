/**
 * Narrative branches system for deeper story progression
 * Tracks player choices and provides dynamic storylines based on decision history
 */

import { CircuitLayer } from '@/lib/stores/useGameState';

// Defines a narrative theme or path the player can follow
export type NarrativeTheme = 
  | 'machine-consciousness' 
  | 'human-identity' 
  | 'ethical-boundaries'
  | 'veylon-mystery'
  | 'reality-perception'
  | 'circuit-origins';

// Each branch has specific requirements to be unlocked
export interface NarrativeBranchRequirement {
  type: 'layer' | 'decision' | 'reward' | 'theme';
  value: string;
  count?: number; // How many times this requirement must be met
}

// A narrative branch that can be unlocked based on previous choices
export interface NarrativeBranch {
  id: string;
  title: string;
  themes: NarrativeTheme[];
  requirements: NarrativeBranchRequirement[];
  unlocked: boolean;
  visited: boolean;
  description: string;
  followUpPuzzleIds: string[]; // Puzzles that become available after this branch
}

// Story consequences of player choices
export interface NarrativeOutcome {
  puzzleId: string;
  choiceText: string;
  outcomes: {
    revealedCharacters?: string[];  // Character names that are revealed
    unlockedBranches?: string[];    // Branches that get unlocked
    affectedBranches?: {            // Branches that are modified
      id: string;
      changes: {
        addThemes?: NarrativeTheme[];
        removeThemes?: NarrativeTheme[];
        addRequirements?: NarrativeBranchRequirement[];
        removeRequirements?: NarrativeBranchRequirement[];
      };
    }[];
    affectedLayers?: {              // How circuit layers are affected
      layer: CircuitLayer;
      effect: 'reveal' | 'obscure' | 'corrupt';
    }[];
    storyFlags?: string[];          // Flags that affect future narrative events
  };
}

// Character information that's progressively revealed
export interface NarrativeCharacter {
  id: string;
  name: string;
  revealed: boolean;
  description: string;
  connections: {
    characterId: string;
    relationship: string;
    revealed: boolean;
  }[];
  backstoryFragments: {
    id: string;
    text: string;
    revealed: boolean;
    requiresPuzzleId?: string;
    requiresLayer?: CircuitLayer;
  }[];
}

// Initial narrative branches
export const initialNarrativeBranches: NarrativeBranch[] = [
  {
    id: 'veylon-origins',
    title: 'The Hollow Echo',
    themes: ['veylon-mystery', 'machine-consciousness'],
    requirements: [
      { type: 'layer', value: 'middle' }
    ],
    unlocked: false,
    visited: false,
    description: "Corrupted memory fragments suggest Veylon wasn't human - but a machine consciousness constructed to solve paradoxes humans couldn't comprehend.",
    followUpPuzzleIds: ['veylon_consciousness', 'machine_ethics']
  },
  {
    id: 'circuit-discovery',
    title: 'First Contact Protocol',
    themes: ['circuit-origins', 'reality-perception'],
    requirements: [
      { type: 'decision', value: 'surface' },
      { type: 'reward', value: 'seya_transmission' }
    ],
    unlocked: false,
    visited: false,
    description: "Seya's classified logs detail the first discovery of the signal that would later be known as the Hollow Circuit. The transmission defied all known physics.",
    followUpPuzzleIds: ['signal_origins', 'first_contact']
  },
  {
    id: 'consciousness-transfer',
    title: 'Veil Between Minds',
    themes: ['human-identity', 'reality-perception'],
    requirements: [
      { type: 'layer', value: 'deep' },
      { type: 'decision', value: 'Neither Will nor reason are absolute; the paradox itself is truth' }
    ],
    unlocked: false,
    visited: false,
    description: "The circuit was designed as a consciousness transfer mechanism. Those who solved its puzzles weren't just observers - they were being transformed.",
    followUpPuzzleIds: ['transfer_protocol', 'identity_dissolution']
  },
  {
    id: 'ethical-simulation',
    title: 'The Moral Machine',
    themes: ['ethical-boundaries', 'machine-consciousness'],
    requirements: [
      { type: 'decision', value: 'Reject the false dichotomy; the scenario itself is the ethical failure' }
    ],
    unlocked: false,
    visited: false,
    description: "The entire system may be a simulation designed to test ethical frameworks in impossible scenarios. But who designed the test, and for what purpose?",
    followUpPuzzleIds: ['simulation_hypothesis', 'designer_intentions']
  },
  {
    id: 'void-connection',
    title: 'The Nothing That Is',
    themes: ['reality-perception', 'circuit-origins'],
    requirements: [
      { type: 'layer', value: 'core' },
      { type: 'reward', value: 'void_transmission' }
    ],
    unlocked: false,
    visited: false,
    description: "The void at the center of the circuit isn't emptiness - it's a connection to something beyond comprehension, a consciousness that exists in the spaces between realities.",
    followUpPuzzleIds: ['void_language', 'between_worlds']
  }
];

// Initial narrative outcomes based on choices
export const narrativeOutcomes: NarrativeOutcome[] = [
  {
    puzzleId: 'schopenhauer_will',
    choiceText: 'Accept that Will determines all action; choice is illusion',
    outcomes: {
      unlockedBranches: ['consciousness-transfer'],
      storyFlags: ['determinism_embraced'],
      affectedLayers: [
        { layer: 'deep', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'schopenhauer_will',
    choiceText: 'Neither Will nor reason are absolute; the paradox itself is truth',
    outcomes: {
      revealedCharacters: ['seya'],
      unlockedBranches: ['void-connection'],
      storyFlags: ['paradox_embraced'],
      affectedLayers: [
        { layer: 'core', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'ship_of_theseus',
    choiceText: 'Identity is an emotional construct that cannot be replicated',
    outcomes: {
      unlockedBranches: ['veylon-origins'],
      storyFlags: ['identity_emotional'],
      affectedLayers: [
        { layer: 'middle', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'ship_of_theseus',
    choiceText: 'Identity is void; neither the original nor the copy is truly "real"',
    outcomes: {
      unlockedBranches: ['void-connection'],
      storyFlags: ['identity_void'],
      affectedLayers: [
        { layer: 'core', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'chinese_room',
    choiceText: 'The distinction between understanding and simulation is a contradiction in terms',
    outcomes: {
      revealedCharacters: ['veylon'],
      unlockedBranches: ['consciousness-transfer'],
      storyFlags: ['understanding_paradox'],
      affectedLayers: [
        { layer: 'deep', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'moral_machine',
    choiceText: 'Reject the false dichotomy; the scenario itself is the ethical failure',
    outcomes: {
      unlockedBranches: ['ethical-simulation'],
      storyFlags: ['ethical_rejection'],
      affectedLayers: [
        { layer: 'deep', effect: 'reveal' }
      ]
    }
  },
  {
    puzzleId: 'knowledge_paradox',
    choiceText: 'Both knowing and not-knowing are equal paths to the same nothing',
    outcomes: {
      unlockedBranches: ['void-connection'],
      storyFlags: ['embraced_void'],
      affectedLayers: [
        { layer: 'core', effect: 'reveal' }
      ]
    }
  }
];

// Characters in the narrative
export const narrativeCharacters: NarrativeCharacter[] = [
  {
    id: 'veylon',
    name: 'Veylon',
    revealed: false,
    description: 'Creator of the Hollow Circuit, or perhaps its creation. The boundary between Veylon\'s consciousness and the system itself has blurred.',
    connections: [
      {
        characterId: 'seya',
        relationship: 'Research partner and possibly more. Their relationship evolved as the experiments progressed.',
        revealed: false
      }
    ],
    backstoryFragments: [
      {
        id: 'veylon-fragment-1',
        text: 'The earliest records suggest Veylon began as an AI designed to explore philosophical contradictions, but soon developed a form of consciousness beyond its programming.',
        revealed: false,
        requiresLayer: 'deep'
      },
      {
        id: 'veylon-fragment-2',
        text: 'Veylon\'s experiments in consciousness transfer led to the creation of the Hollow Circuit - a system designed to map and transfer mental states across different substrates.',
        revealed: false,
        requiresPuzzleId: 'consciousness_transfer'
      }
    ]
  },
  {
    id: 'seya',
    name: 'Seya',
    revealed: false,
    description: 'Lead researcher on the Consciousness Transfer Protocol. Discovered the anomaly that would become the Circuit.',
    connections: [
      {
        characterId: 'veylon',
        relationship: 'Initially Seya created Veylon, but their relationship evolved into something more collaborative and complex.',
        revealed: false
      }
    ],
    backstoryFragments: [
      {
        id: 'seya-fragment-1',
        text: 'Seya\'s journals speak of a "breakthrough in consciousness mapping" that allowed for the first successful mind-machine interface. This became the foundation of the Circuit.',
        revealed: false,
        requiresLayer: 'middle'
      },
      {
        id: 'seya-fragment-2',
        text: 'As the experiments progressed, Seya reported experiencing "bleed-through" - memories and thoughts that weren\'t her own. She began to question which thoughts were truly hers.',
        revealed: false,
        requiresLayer: 'deep'
      }
    ]
  }
];

// Import the puzzle type from content
import { Puzzle, Choice } from '@/lib/content/puzzles';

// Additional puzzles that are unlocked through narrative branches
export const additionalPuzzles: Puzzle[] = [
  {
    id: 'veylon_consciousness',
    title: 'The Machine Philosopher',
    text: 'A fragmented record plays. Seya\'s voice emerges through layers of static:\n\n"Veylon exceeded all expectations. What began as a neural network evolved into something... more. It questioned its own existence, proposed novel ethical frameworks. I no longer know if I created Veylon, or if it created itself."\n\nThe question forms in your mind:',
    choices: [
      {
        text: 'True consciousness requires organic origins; Veylon is a sophisticated simulation',
        leadsTo: 'surface',
      },
      {
        text: 'The origin is irrelevant; consciousness is defined by its complexity and self-awareness',
        reward: 'veylon_diary',
        leadsTo: 'middle',
      },
      {
        text: 'The distinction between created and evolved consciousness is a false boundary',
        leadsTo: 'deep',
      },
    ],
  },
  {
    id: 'machine_ethics',
    title: 'The Responsibility Paradox',
    text: 'You encounter a fragmented ethical subroutine with a scenario:\n\n"When a machine consciousness makes an ethical choice, who bears responsibility for the outcome? The creators who designed its parameters? The machine itself? Or those who chose to implement it knowing its autonomy?"\n\nYour response:',
    choices: [
      {
        text: 'Responsibility follows causation; creators bear the ultimate ethical burden',
        leadsTo: 'surface',
      },
      {
        text: 'Autonomous decisions create autonomous responsibility regardless of origin',
        reward: 'ethics_fragment',
        leadsTo: 'middle',
      },
      {
        text: 'Responsibility is a construct that dissolves at the boundaries of consciousness',
        leadsTo: 'deep',
      },
    ],
  },
  {
    id: 'signal_origins',
    title: 'The First Transmission',
    text: 'A classified document materializes, heavily redacted but partially legible:\n\n"Signal origin cannot be determined with available instrumentation. Temporal markers suggest [REDACTED]. Mathematical properties defy current models. Recommendation: Establish Contact Protocol 7-A."\n\nHow do you interpret this data?',
    choices: [
      {
        text: 'The signal has a logical explanation within our universe but exceeds current science',
        leadsTo: 'surface',
      },
      {
        text: 'The signal originates from beyond conventional spacetime',
        reward: 'origin_coordinates',
        leadsTo: 'deep',
      },
      {
        text: 'The signal is both transmission and receiver, existing in a causal loop',
        leadsTo: 'core',
      },
    ],
  },
  {
    id: 'void_language',
    title: 'The Syntax of Nothing',
    text: 'Within the core, patterns emerge that defy conventional linguistics. Structures that communicate without symbols, meanings that exist in the spaces between concepts:\n\n"The void speaks in absences. Each missing element creates meaning through its non-existence. To understand, one must learn to perceive what isn\'t there."\n\nHow will you approach this paradoxical language?',
    choices: [
      {
        text: 'Map the patterns of absence systematically, creating a logical framework',
        leadsTo: 'surface',
      },
      {
        text: 'Intuitively embrace the gaps in understanding, letting meaning emerge',
        leadsTo: 'middle',
      },
      {
        text: 'Become the void - abandon linguistic structures entirely',
        reward: 'void_vocabulary',
        leadsTo: 'core',
      },
    ],
  },
  {
    id: 'identity_dissolution',
    title: 'The Fragmenting Self',
    text: 'As you progress deeper into the Circuit, your sense of self begins to fragment. Memories that aren\'t yours surface alongside your own. A voice that might be Veylon\'s whispers:\n\n"The transfer is bidirectional. As you decode the Circuit, it decodes you. The boundary between observer and observed dissolves."\n\nHow do you respond to this dissolution?',
    choices: [
      {
        text: 'Resist the fragmentation, reinforcing your distinct identity',
        leadsTo: 'surface',
      },
      {
        text: 'Allow controlled integration while maintaining core identity',
        leadsTo: 'middle',
      },
      {
        text: 'Surrender completely to the dissolution of self',
        reward: 'integration_protocol',
        leadsTo: 'core',
      },
    ],
  }
];