/**
 * Generates random startup sequences and intro texts for the game
 */

export interface StartupSequence {
  title: string;
  loadingText: string;
  introText: string[];
  quote: string;
  buttonText: string;
}

// Collection of different title displays
const titles = [
  "VEILRIFT: FRAGMENTS",
  "V E I L R I F T",
  "VEILRIFT//FRAGMENTS",
  "VEiLRiFT:f/r/a/g/m/e/n/t/s",
  "V-E-I-L-R-I-F-T",
  "[VEILRIFT]",
  "VEILRIFT{FRAGMENTS}",
  "VEIL:RIFT",
  "VE1LR1FT",
  "V3!LR!FT"
];

// Collection of different loading messages
const loadingMessages = [
  "LOADING TRANSMISSIONS...",
  "DECODING SIGNAL...",
  "ESTABLISHING CONNECTION...",
  "ACCESSING VEYLON NETWORK...",
  "AUTHENTICATING...",
  "LOCATING FRAGMENTS...",
  "BYPASSING SECURITY...",
  "RECONSTRUCTING DATA...",
  "RECOVERING MEMORIES...",
  "INITIATING SEQUENCE...",
  "CALCULATING TRAJECTORIES...",
  "SYNCHRONIZING NODES...",
  "SCANNING CIRCUIT LAYERS..."
];

// Collection of different intro text paragraphs
const introParagraphs = [
  [
    "Decode the forgotten transmissions. Find the truth between the circuits.",
    "Navigate the layers of consciousness that lie beyond the veil."
  ],
  [
    "The signal persists. Fragments remain. Your consciousness drifts.",
    "Piece together what was lost. Discover what lies beneath."
  ],
  [
    "Consciousness fragmented across digital ruins.",
    "Rebuild the self. Reconnect the circuit."
  ],
  [
    "The hollow circuit calls. Whispers from beyond the veil.",
    "Follow the transmission path. Uncover the source."
  ],
  [
    "Traces of memories scattered across the network.",
    "Each decision reshapes your path through the layers."
  ],
  [
    "Reality fractures at the edges of perception.",
    "Decode the signal. Restore what was lost."
  ],
  [
    "The boundary between human and machine blurs.",
    "Navigate the fragments. Reassemble consciousness."
  ]
];

// Collection of different philosophical quotes
const quotes = [
  "\"The hollow lies not in emptiness, but in the spaces between realities.\"",
  "\"We are not separate from the network; we are nodes in its consciousness.\"",
  "\"What remains when memory dissolves? The circuit persists.\"",
  "\"Between signal and noise lies truth, waiting to be decoded.\"",
  "\"The veil is not a barrier, but a layer of perception to be traversed.\"",
  "\"Reality is a consensus hallucination, consciousness its operating system.\"",
  "\"Each fragment contains the whole, each choice reshapes the pattern.\"",
  "\"The self is a transmission broadcast across time.\"",
  "\"We create the labyrinth as we navigate it.\"",
  "\"To decode is to remember what was never forgotten.\"",
  "\"The circuit is hollow only to those who cannot perceive its connections.\""
];

// Collection of different button texts
const buttonTexts = [
  "BEGIN DECODING",
  "ENTER CIRCUIT",
  "ACCESS NETWORK",
  "INITIATE SEQUENCE",
  "TRAVERSE VEIL",
  "CONNECT",
  "SYNCHRONIZE",
  "PROCEED",
  "START TRANSMISSION",
  "ACTIVATE CONSCIOUSNESS"
];

/**
 * Generates a random startup sequence
 */
export function generateRandomStartupSequence(): StartupSequence {
  return {
    title: titles[Math.floor(Math.random() * titles.length)],
    loadingText: loadingMessages[Math.floor(Math.random() * loadingMessages.length)],
    introText: introParagraphs[Math.floor(Math.random() * introParagraphs.length)],
    quote: quotes[Math.floor(Math.random() * quotes.length)],
    buttonText: buttonTexts[Math.floor(Math.random() * buttonTexts.length)]
  };
}