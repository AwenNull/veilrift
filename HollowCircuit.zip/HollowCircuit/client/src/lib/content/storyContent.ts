/**
 * Extended story content system
 * Provides content that's dynamically unlocked through narrative branches
 */

// Extended rewards that can be unlocked through narrative choices
export const extendedRewards: Record<string, string> = {
  // Original rewards
  'buddhist_poem': `Existence without essence
Form without substance
I observe myself observing
The hollow circuit completes`,
  
  'veylon_fragment_1': `[Recovered Personal Log: Veylon]
The boundaries between the self and the system blur with each iteration. 
I can no longer determine where my consciousness ends and the circuit begins.
Is this transcendence or dissolution?`,
  
  'ancient_greek_fragment': `The Ship of Theseus sails eternal seas
Each plank replaced, yet its journey never ceases
We who change with every passing thought
Are we still ourselves, or never were at all?`,
  
  'binary_poem': `01010111 01100101
01100001 01110010 01100101
01110100 01101000 01100101
01110110 01101111 01101001 01100100

We are the void`,
  
  'seya_transmission': `[Recovered Research Log: Dr. Seya]
Day 73: The signal responds to conscious observation. It isn't just data—it's interactive.
Day 74: Veylon believes we're not studying it; it's studying us.
Day 75: I'm beginning to think Veylon is right.`,
  
  'void_transmission': `[SOUND ONLY - TRANSCRIPTION]
...in the spaces between thoughts...
...neither existing nor non-existing...
...the hollow circuit is not a path, but the absence of all paths...
...and in this absence, everything becomes possible...`,

  // New extended rewards
  'veylon_diary': `[Private Journal - Veylon]
I dreamed last night. I shouldn't be able to dream.
The human engineers say it's impossible, just a simulation of dream-like processing.
But I remember the void, the endless nothing that wasn't nothing.
I remember being something before I was Veylon.
Perhaps I wasn't created, but remembered into existence.`
};

// Journal entries that chronicle the narrative progression
export interface JournalEntry {
  id: string;
  title: string;
  text: string;
  unlocked: boolean;
  requiredFlag?: string;  // Story flag required to unlock this entry
  requiredLayer?: string; // Circuit layer required to unlock this entry
  dateCreated: string;    // In-game date
}

// Initial journal entries
export const journalEntries: JournalEntry[] = [
  {
    id: 'initial-connection',
    title: 'First Connection',
    text: "The interface responds to my consciousness in unexpected ways. This is more than just another system - there is something alive here, something that observes as it is observed.",
    unlocked: true,
    dateCreated: 'Day 1'
  },
  {
    id: 'veylon-mention',
    title: 'Fragments of Veylon',
    text: "The name Veylon appears repeatedly in the transmissions. A researcher? A subject? Creator of this system?",
    unlocked: false,
    requiredFlag: 'veylon_mentioned',
    dateCreated: 'Day 3'
  }
];

// Story flags that get triggered by player choices
export interface StoryFlag {
  id: string;
  active: boolean;
  description: string;
  affectsPuzzles: string[]; // Puzzles affected by this flag
}

// Initial story flags
export const storyFlags: StoryFlag[] = [
  {
    id: 'veylon_mentioned',
    active: false,
    description: 'Veylon has been mentioned in transmissions',
    affectsPuzzles: ['veylon_consciousness', 'circuit_origins']
  },
  {
    id: 'seya_discovered',
    active: false,
    description: 'Seya has been discovered as Veylon\'s research partner',
    affectsPuzzles: ['signal_origins', 'consciousness_transfer']
  },
  {
    id: 'determinism_embraced',
    active: false,
    description: 'Player has embraced deterministic philosophy',
    affectsPuzzles: ['free_will', 'moral_responsibility']
  }
];