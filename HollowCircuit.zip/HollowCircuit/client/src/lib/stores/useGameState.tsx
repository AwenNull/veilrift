import { create } from 'zustand';
import { puzzles } from '@/lib/content/puzzles';
import { transmissions } from '@/lib/content/transmissions';
import { rewards } from '@/lib/content/rewards';

// Circuit layer - player descends through these as they make choices
export type CircuitLayer = 'surface' | 'middle' | 'deep' | 'core';

// Game phases
export type GamePhase = 'decoding' | 'decision' | 'reflection';

// Connection between nodes in the circuit
export interface Connection {
  from: number;
  to: number;
}

// Import the narrative branch system
import { 
  NarrativeBranch, initialNarrativeBranches, 
  narrativeOutcomes, narrativeCharacters,
  NarrativeCharacter, additionalPuzzles
} from '@/lib/content/narrativeBranches';

// Import story content system
import {
  extendedRewards, journalEntries, storyFlags,
  JournalEntry, StoryFlag
} from '@/lib/content/storyContent';

// State interface
interface GameState {
  // Circuit configuration
  nodePositions: [number, number, number][];
  connections: Connection[];
  activeNode: number | null;
  playerPath: number[];
  
  // Game progression
  gameInitialized: boolean;
  currentLayer: CircuitLayer;
  currentPhase: GamePhase;
  currentPuzzleIndex: number;
  currentTransmissionIndex: number;
  decisions: string[];
  revealedRewards: string[];
  
  // Narrative branching
  narrativeBranches: NarrativeBranch[];
  activeBranchId: string | null;
  narrativeCharacters: NarrativeCharacter[];
  availablePuzzles: typeof puzzles;
  storyFlags: StoryFlag[];
  journalEntries: JournalEntry[];
  
  // Actions
  initGame: () => void;
  advanceToNode: (nodeIndex: number) => void;
  makeDecision: (choice: string, puzzleId: string) => void;
  completeTransmission: () => void;
  addReward: (rewardId: string) => void;
  unlockNarrativeBranch: (branchId: string) => void;
  visitNarrativeBranch: (branchId: string) => void;
  activateStoryFlag: (flagId: string) => void;
  revealCharacter: (characterId: string) => void;
  unlockJournalEntry: (entryId: string) => void;
}

export const useGameState = create<GameState>((set, get) => ({
  // Initial circuit configuration
  nodePositions: [
    [0, 0, 0],        // Center - start node
    [1.5, 0.5, 0],    // Top right
    [0.8, -1.3, 0],   // Bottom right
    [-0.8, -1.3, 0],  // Bottom left
    [-1.5, 0.5, 0],   // Top left
    [0, 1.5, 0],      // Top
    [0, -2, 0],       // Bottom
    [2.5, -0.5, 0],   // Far right
    [-2.5, -0.5, 0],  // Far left
  ],
  connections: [
    { from: 0, to: 1 },
    { from: 0, to: 2 },
    { from: 0, to: 3 },
    { from: 0, to: 4 },
    { from: 0, to: 5 },
    { from: 1, to: 7 },
    { from: 2, to: 6 },
    { from: 3, to: 6 },
    { from: 4, to: 8 },
    { from: 5, to: 1 },
    { from: 5, to: 4 },
  ],
  activeNode: null,
  playerPath: [],
  
  // Game state
  gameInitialized: false,
  currentLayer: 'surface',
  currentPhase: 'decoding',
  currentPuzzleIndex: 0,
  currentTransmissionIndex: 0,
  decisions: [],
  revealedRewards: [],
  
  // Narrative branching
  narrativeBranches: initialNarrativeBranches,
  activeBranchId: null,
  narrativeCharacters: narrativeCharacters,
  availablePuzzles: [...puzzles], // Start with the default puzzles
  storyFlags: storyFlags,
  journalEntries: journalEntries,
  
  // Initialize the game
  initGame: () => {
    const combinedPuzzles = [...puzzles, ...additionalPuzzles.slice(0, 2)]; // Add a couple additional puzzles by default
    
    set({
      gameInitialized: true,
      activeNode: 0,  // Start at the center node
      playerPath: [0],
      currentPhase: 'decoding',
      currentPuzzleIndex: 0,
      currentTransmissionIndex: 0,
      availablePuzzles: combinedPuzzles,
    });
    
    // Unlock the first journal entry
    get().unlockJournalEntry('initial-connection');
  },
  
  // Move to a connected node in the circuit
  advanceToNode: (nodeIndex: number) => {
    const { activeNode, connections, playerPath, currentPhase } = get();
    
    // Log the current state before advancing
    console.log("Advancing to node", nodeIndex);
    console.log("Current phase:", currentPhase);
    console.log("Active node:", activeNode);
    console.log("Is already in path:", playerPath.includes(nodeIndex));
    
    // Verify the node is connected to the current active node
    const isConnected = connections.some(c => 
      (c.from === activeNode && c.to === nodeIndex) || 
      (c.to === activeNode && c.from === nodeIndex)
    );
    console.log("Is connected:", isConnected);
    
    if (isConnected && !playerPath.includes(nodeIndex)) {
      console.log("Updating game state for new node");
      set(state => ({
        activeNode: nodeIndex,
        playerPath: [...state.playerPath, nodeIndex],
        currentPhase: 'decoding',  // Start with decoding a new transmission
      }));
      
      // Log the phase transition
      console.log("Phase changed to: decoding");
    } else {
      console.log("Node advancement rejected:", 
                 !isConnected ? "not connected" : "already in path");
    }
  },
  
  // Process a player's decision with enhanced narrative branching
  makeDecision: (choice: string, puzzleId: string) => {
    const { decisions, currentPuzzleIndex, availablePuzzles } = get();
    const newDecisions = [...decisions, choice];
    
    // Determine which layer to move to based on decisions
    let newLayer: CircuitLayer = 'surface';
    const surfaceChoices = newDecisions.filter(d => d.includes('logic') || d.includes('reason')).length;
    const middleChoices = newDecisions.filter(d => d.includes('emotion') || d.includes('intuition')).length;
    const deepChoices = newDecisions.filter(d => d.includes('paradox') || d.includes('contradiction')).length;
    const coreChoices = newDecisions.filter(d => d.includes('void') || d.includes('nothing')).length;
    
    // Simple algorithm to determine layer
    const max = Math.max(surfaceChoices, middleChoices, deepChoices, coreChoices);
    if (max === coreChoices && coreChoices > 0) newLayer = 'core';
    else if (max === deepChoices && deepChoices > 0) newLayer = 'deep';
    else if (max === middleChoices && middleChoices > 0) newLayer = 'middle';
    else newLayer = 'surface';
    
    // Check for narrative outcomes based on this choice
    const matchingOutcome = narrativeOutcomes.find(
      outcome => outcome.puzzleId === puzzleId && outcome.choiceText === choice
    );
    
    if (matchingOutcome) {
      console.log("Narrative outcome triggered:", matchingOutcome);
      
      // Process character revelations
      if (matchingOutcome.outcomes.revealedCharacters) {
        matchingOutcome.outcomes.revealedCharacters.forEach(charId => {
          get().revealCharacter(charId);
        });
      }
      
      // Process branch unlocks
      if (matchingOutcome.outcomes.unlockedBranches) {
        matchingOutcome.outcomes.unlockedBranches.forEach(branchId => {
          get().unlockNarrativeBranch(branchId);
        });
      }
      
      // Process story flags
      if (matchingOutcome.outcomes.storyFlags) {
        matchingOutcome.outcomes.storyFlags.forEach(flagId => {
          get().activateStoryFlag(flagId);
        });
      }
      
      // Process layer effects
      if (matchingOutcome.outcomes.affectedLayers) {
        // This would apply visual or gameplay effects to specific layers
        // For now, we'll just log this
        console.log("Layers affected:", matchingOutcome.outcomes.affectedLayers);
      }
    }
    
    // Check if there's a specific branch associated with this choice
    const currentPuzzle = availablePuzzles[currentPuzzleIndex];
    const selectedChoice = currentPuzzle.choices.find(c => c.text === choice);
    const choiceLayer = selectedChoice?.leadsTo || newLayer;
    
    // Update state
    set(state => ({
      decisions: newDecisions,
      currentLayer: choiceLayer,
      currentPhase: 'reflection',  // Brief reflection phase
      currentPuzzleIndex: (currentPuzzleIndex + 1) % availablePuzzles.length,
    }));
    
    // Automatically advance to the next phase after reflection
    setTimeout(() => {
      set({ currentPhase: 'decoding' });
    }, 2000);
  },
  
  // Complete the current transmission decoding
  completeTransmission: () => {
    console.log("Completing transmission, moving to decision phase");
    
    // Set the phase to decision
    set(state => {
      console.log("Current state:", state);
      console.log("Setting phase to decision");
      
      return {
        currentPhase: 'decision',
        currentTransmissionIndex: (state.currentTransmissionIndex + 1) % transmissions.length,
      };
    });
    
    // Log the new phase to verify it changed
    const newState = get();
    console.log("New phase after completion:", newState.currentPhase);
  },
  
  // Add a new reward (text fragment, poem, etc.) from combined rewards
  addReward: (rewardId: string) => {
    // Check both the original rewards and extended rewards
    const rewardText = rewards[rewardId] || extendedRewards[rewardId];
    
    if (rewardText) {
      set(state => ({
        revealedRewards: [...state.revealedRewards, rewardText],
      }));
      console.log(`Reward unlocked: ${rewardId}`);
    } else {
      console.warn(`Attempted to unlock non-existent reward: ${rewardId}`);
    }
  },
  
  // Unlock a narrative branch
  unlockNarrativeBranch: (branchId: string) => {
    set(state => {
      const updatedBranches = state.narrativeBranches.map(branch => 
        branch.id === branchId ? { ...branch, unlocked: true } : branch
      );
      
      console.log(`Narrative branch unlocked: ${branchId}`);
      
      return { 
        narrativeBranches: updatedBranches
      };
    });
    
    // Possibly unlock new puzzles related to this branch
    const branch = get().narrativeBranches.find(b => b.id === branchId);
    if (branch && branch.followUpPuzzleIds.length > 0) {
      // Find puzzles that should be added from additional puzzles
      const puzzlesToAdd = additionalPuzzles.filter(p => 
        branch.followUpPuzzleIds.includes(p.id) && 
        !get().availablePuzzles.some(existing => existing.id === p.id)
      );
      
      if (puzzlesToAdd.length > 0) {
        set(state => ({
          availablePuzzles: [...state.availablePuzzles, ...puzzlesToAdd]
        }));
        console.log(`Added ${puzzlesToAdd.length} new puzzles related to branch: ${branchId}`);
      }
    }
  },
  
  // Mark a narrative branch as visited
  visitNarrativeBranch: (branchId: string) => {
    set(state => {
      const updatedBranches = state.narrativeBranches.map(branch => 
        branch.id === branchId ? { ...branch, visited: true } : branch
      );
      
      return { 
        narrativeBranches: updatedBranches,
        activeBranchId: branchId 
      };
    });
  },
  
  // Activate a story flag
  activateStoryFlag: (flagId: string) => {
    set(state => {
      const updatedFlags = state.storyFlags.map(flag => 
        flag.id === flagId ? { ...flag, active: true } : flag
      );
      
      console.log(`Story flag activated: ${flagId}`);
      
      // Check if any journal entries should be unlocked by this flag
      const journalEntriesToUnlock = state.journalEntries
        .filter(entry => !entry.unlocked && entry.requiredFlag === flagId);
      
      if (journalEntriesToUnlock.length > 0) {
        journalEntriesToUnlock.forEach(entry => {
          get().unlockJournalEntry(entry.id);
        });
      }
      
      return { storyFlags: updatedFlags };
    });
  },
  
  // Reveal a character's information
  revealCharacter: (characterId: string) => {
    set(state => {
      const updatedCharacters = state.narrativeCharacters.map(char => 
        char.id === characterId 
        ? { 
            ...char, 
            revealed: true,
            backstoryFragments: char.backstoryFragments.map(fragment => {
              // Reveal initial fragments automatically
              if (!fragment.requiresPuzzleId && !fragment.requiresLayer) {
                return { ...fragment, revealed: true };
              }
              return fragment;
            })
          } 
        : char
      );
      
      console.log(`Character revealed: ${characterId}`);
      
      return { narrativeCharacters: updatedCharacters };
    });
  },
  
  // Unlock a journal entry
  unlockJournalEntry: (entryId: string) => {
    set(state => {
      const updatedEntries = state.journalEntries.map(entry => 
        entry.id === entryId ? { ...entry, unlocked: true } : entry
      );
      
      console.log(`Journal entry unlocked: ${entryId}`);
      
      return { journalEntries: updatedEntries };
    });
  }
}));
