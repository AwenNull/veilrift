/**
 * Glitch effect utilities
 * Creates digital distortion effects for the game's aesthetic
 */

// Apply a glitch effect to a canvas context
export function applyGlitchEffect(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number = 0.5
) {
  // Only occasionally apply glitches based on intensity (but more frequently now)
  if (Math.random() > intensity * 0.5) return;
  
  // Choose random glitch effects to apply (increased max count for more visual chaos)
  const effectCount = Math.floor(Math.random() * 4) + 2;
  
  for (let i = 0; i < effectCount; i++) {
    const effectType = Math.floor(Math.random() * 6); // Added two new effects
    
    switch (effectType) {
      case 0:
        // Horizontal lines
        drawHorizontalGlitchLines(ctx, width, height, intensity * 1.5);
        break;
      case 1:
        // RGB shift
        applyRGBShift(ctx, width, height, intensity * 1.2);
        break;
      case 2:
        // Noise
        applyNoise(ctx, width, height, intensity * 1.3);
        break;
      case 3:
        // Block displacement
        applyBlockDisplacement(ctx, width, height, intensity * 1.5);
        break;
      case 4:
        // Vertical tear (new effect)
        applyVerticalTear(ctx, width, height, intensity);
        break;
      case 5:
        // Data corruption blocks (new effect)
        applyDataCorruption(ctx, width, height, intensity);
        break;
    }
  }
}

// Draw horizontal glitch lines
function drawHorizontalGlitchLines(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number
) {
  const lineCount = Math.floor(Math.random() * 5 * intensity) + 1;
  
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  
  for (let i = 0; i < lineCount; i++) {
    const y = Math.floor(Math.random() * height);
    const h = Math.floor(Math.random() * 5) + 1;
    const opacity = Math.random() * 0.8 + 0.2;
    
    ctx.globalAlpha = opacity;
    ctx.fillRect(0, y, width, h);
  }
  
  ctx.globalAlpha = 1;
}

// Apply RGB shift effect
function applyRGBShift(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number
) {
  // Only apply to certain regions
  const regionCount = Math.floor(Math.random() * 3 * intensity) + 1;
  
  for (let i = 0; i < regionCount; i++) {
    const x = Math.floor(Math.random() * width);
    const y = Math.floor(Math.random() * height);
    const w = Math.floor(Math.random() * 100 * intensity) + 50;
    const h = Math.floor(Math.random() * 40 * intensity) + 10;
    
    // Create semi-transparent red and blue overlays
    ctx.globalAlpha = Math.random() * 0.3 + 0.1;
    ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
    ctx.fillRect(x - w * 0.1, y, w, h);
    
    ctx.fillStyle = 'rgba(0, 0, 255, 0.5)';
    ctx.fillRect(x + w * 0.1, y, w, h);
  }
  
  ctx.globalAlpha = 1;
}

// Apply noise effect
function applyNoise(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number
) {
  const pixelSize = Math.floor(Math.random() * 3) + 1;
  const opacity = Math.random() * 0.2 + 0.1;
  
  ctx.globalAlpha = opacity;
  
  for (let y = 0; y < height; y += pixelSize) {
    for (let x = 0; x < width; x += pixelSize) {
      if (Math.random() < intensity * 0.3) {
        const brightness = Math.random() * 255;
        ctx.fillStyle = `rgb(${brightness}, ${brightness}, ${brightness})`;
        ctx.fillRect(x, y, pixelSize, pixelSize);
      }
    }
  }
  
  ctx.globalAlpha = 1;
}

// Displace blocks of the screen
function applyBlockDisplacement(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number
) {
  const blockCount = Math.floor(Math.random() * 5 * intensity) + 1;
  
  for (let i = 0; i < blockCount; i++) {
    const blockHeight = Math.floor(Math.random() * 50 * intensity) + 10;
    const y = Math.floor(Math.random() * (height - blockHeight));
    const displacement = Math.floor(Math.random() * 30 * intensity) + 5;
    
    // Add a displaced "scan line" rectangle
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.fillRect(0, y, width, blockHeight);
    
    // Add a black line at the top of the block
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, y, width, 1);
    
    // Add a black line at the bottom of the block
    ctx.fillRect(0, y + blockHeight, width, 1);
    
    // Add vertical displacement markers
    const markerCount = Math.floor(Math.random() * 5) + 2;
    for (let j = 0; j < markerCount; j++) {
      const markerX = Math.floor(Math.random() * width);
      ctx.fillRect(markerX, y, 2, blockHeight);
    }
  }
}

// Apply a vertical tear/slit effect
export function applyVerticalTear(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number = 0.5
): void {
  // Number of tears depends on intensity
  const tearCount = Math.floor(intensity * 3) + 1;
  
  for (let i = 0; i < tearCount; i++) {
    // Random position for the tear
    const x = Math.floor(Math.random() * width);
    const tearWidth = Math.floor(Math.random() * 20) + 5;
    
    // Random offset for the tear displacement
    const offsetX = Math.floor((Math.random() * 20) - 10);
    
    // Create a vertical tear
    const imageData = ctx.getImageData(x, 0, tearWidth, height);
    ctx.clearRect(x, 0, tearWidth, height);
    
    // Draw the right side of the tear with offset
    ctx.putImageData(imageData, x + offsetX, 0);
    
    // Draw glitchy line at tear edges
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.fillRect(x, 0, 1, height);
    ctx.fillRect(x + tearWidth + offsetX, 0, 1, height);
  }
}

// Apply data corruption blocks/artifacts
export function applyDataCorruption(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number = 0.5
): void {
  // Number of corruption blocks
  const blockCount = Math.floor(intensity * 10) + 3;
  
  for (let i = 0; i < blockCount; i++) {
    // Random position and size for corruption block
    const x = Math.floor(Math.random() * width);
    const y = Math.floor(Math.random() * height);
    const blockWidth = Math.floor(Math.random() * 40) + 10;
    const blockHeight = Math.floor(Math.random() * 40) + 10;
    
    // Get current data and manipulate it
    const imageData = ctx.getImageData(x, y, blockWidth, blockHeight);
    const data = imageData.data;
    
    // Different corruption styles
    const corruptionType = Math.floor(Math.random() * 4);
    
    switch (corruptionType) {
      case 0: // Color channel swap
        for (let j = 0; j < data.length; j += 4) {
          // Swap R and B channels
          const temp = data[j];
          data[j] = data[j + 2];
          data[j + 2] = temp;
        }
        break;
      
      case 1: // Pixelation
        for (let y = 0; y < blockHeight; y += 4) {
          for (let x = 0; x < blockWidth; x += 4) {
            const idx = (y * blockWidth + x) * 4;
            if (idx >= data.length) continue;
            
            // Sample one pixel and apply to a block
            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            
            // Apply to 4x4 block
            for (let by = 0; by < 4 && y + by < blockHeight; by++) {
              for (let bx = 0; bx < 4 && x + bx < blockWidth; bx++) {
                const targetIdx = ((y + by) * blockWidth + (x + bx)) * 4;
                if (targetIdx >= data.length) continue;
                
                data[targetIdx] = r;
                data[targetIdx + 1] = g;
                data[targetIdx + 2] = b;
              }
            }
          }
        }
        break;
      
      case 2: // Static noise
        for (let j = 0; j < data.length; j += 4) {
          const noiseValue = Math.floor(Math.random() * 255);
          data[j] = noiseValue; // R
          data[j + 1] = noiseValue; // G
          data[j + 2] = noiseValue; // B
        }
        break;
      
      case 3: // Smear/repeat
        for (let y = 0; y < blockHeight; y++) {
          // Take first pixel of each row and repeat
          if (y * blockWidth * 4 >= data.length) continue;
          
          const r = data[y * blockWidth * 4];
          const g = data[y * blockWidth * 4 + 1];
          const b = data[y * blockWidth * 4 + 2];
          
          for (let x = 0; x < blockWidth; x++) {
            const idx = (y * blockWidth + x) * 4;
            if (idx >= data.length) continue;
            
            data[idx] = r;
            data[idx + 1] = g;
            data[idx + 2] = b;
          }
        }
        break;
    }
    
    // Put corrupted data back
    ctx.putImageData(imageData, x, y);
    
    // Add a frame around the corrupted area
    if (Math.random() < 0.3) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.strokeRect(x, y, blockWidth, blockHeight);
    }
  }
}

// Create a text corruption effect
export function corruptText(text: string, corruptionLevel: number = 0.1): string {
  if (corruptionLevel <= 0) return text;
  
  const chars = text.split('');
  const glitchChars = ['█', '▓', '▒', '░', '▀', '▄', '■', '□', '▬', '▌', '▐', '▖', '▗', '▘', '▝'];
  
  // Apply corruption based on level
  for (let i = 0; i < chars.length; i++) {
    if (Math.random() < corruptionLevel) {
      // Replace with a glitch character
      chars[i] = glitchChars[Math.floor(Math.random() * glitchChars.length)];
    }
  }
  
  return chars.join('');
}

// Create a signal degradation effect (for progressively corrupted text)
export function degradeSignal(text: string, strength: number = 1.0): string {
  if (strength >= 1) return text;
  if (strength <= 0) return corruptText(text, 0.8);
  
  // Split into segments
  const segments: string[] = [];
  const words = text.split(' ');
  let currentSegment = '';
  
  for (let i = 0; i < words.length; i++) {
    currentSegment += words[i] + ' ';
    
    // Randomly end a segment
    if (Math.random() < 0.2 || i === words.length - 1) {
      segments.push(currentSegment.trim());
      currentSegment = '';
    }
  }
  
  // Apply varying levels of corruption to segments
  return segments.map(segment => {
    const corruptionLevel = Math.max(0, (1 - strength) * Math.random() * 0.5);
    return corruptText(segment, corruptionLevel);
  }).join(' ');
}
