/**
 * Cross-hatching drawing effect
 * Creates a sketchy, hand-drawn style that fits the 
 * minimalist black-and-white aesthetic of the game
 */

export function drawCrossHatch(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  density: number = 0.5,
  angle: number = Math.PI / 4,
  lineWidth: number = 1
) {
  const spacing = Math.max(3, 20 * (1 - density)); // Line spacing based on density
  
  ctx.save();
  ctx.strokeStyle = 'white';
  ctx.lineWidth = lineWidth;
  ctx.translate(x, y);
  
  // First set of hatch lines
  drawHatchLines(ctx, width, height, spacing, angle);
  
  // Second set of hatch lines (perpendicular)
  drawHatchLines(ctx, width, height, spacing, angle + Math.PI / 2);
  
  ctx.restore();
}

function drawHatchLines(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  spacing: number,
  angle: number
) {
  // Calculate the diagonal length to ensure we cover the whole area
  const diagLength = Math.sqrt(width * width + height * height);
  
  // Rotate the context
  ctx.save();
  ctx.rotate(angle);
  
  // Calculate bounds after rotation to ensure we cover the area
  const bound = diagLength;
  const startX = -bound;
  const endX = bound;
  
  // Draw the hatch lines
  for (let x = startX; x < endX; x += spacing) {
    // Add slight randomness to line positions for a hand-drawn feel
    const jitterX = x + (Math.random() * 2 - 1);
    
    ctx.beginPath();
    ctx.moveTo(jitterX, -bound);
    
    // Create slightly wobbly lines
    let prevY = -bound;
    for (let y = -bound + 10; y < bound; y += 10) {
      // Add slight horizontal variation for a hand-drawn effect
      const jitter = Math.random() * 2 - 1;
      ctx.lineTo(jitterX + jitter, y);
      prevY = y;
    }
    
    ctx.stroke();
  }
  
  ctx.restore();
}

export function applySketchFilter(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number
) {
  // Save current drawing
  const imageData = ctx.getImageData(x, y, width, height);
  
  // Clear area
  ctx.clearRect(x, y, width, height);
  
  // Apply cross-hatching based on darkness
  for (let i = 0; i < height; i += 10) {
    for (let j = 0; j < width; j += 10) {
      // Get the brightness of this region
      const brightness = getSectionBrightness(imageData, j, i, 10, 10, width);
      
      // Draw cross-hatching with density based on brightness
      if (brightness < 0.8) { // Only draw where it's not too bright
        const density = 1 - brightness; // Darker areas get denser hatching
        drawCrossHatch(ctx, x + j, y + i, 10, 10, density);
      }
    }
  }
}

function getSectionBrightness(
  imageData: ImageData,
  x: number,
  y: number,
  width: number,
  height: number,
  fullWidth: number
): number {
  let totalBrightness = 0;
  let pixelCount = 0;
  
  for (let i = y; i < y + height && i < imageData.height; i++) {
    for (let j = x; j < x + width && j < imageData.width; j++) {
      const index = (i * fullWidth + j) * 4;
      // Calculate brightness from RGB
      const r = imageData.data[index];
      const g = imageData.data[index + 1];
      const b = imageData.data[index + 2];
      // Simple brightness formula
      const brightness = (r + g + b) / (3 * 255);
      totalBrightness += brightness;
      pixelCount++;
    }
  }
  
  return pixelCount > 0 ? totalBrightness / pixelCount : 1;
}
