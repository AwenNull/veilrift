/**
 * Enhanced glitch effects for visual elements
 */

// Corrupt text with various glitch patterns
export function corruptText(text: string, severity: number = 0.3): string {
  if (!text) return text;
  
  // Unicode characters for glitch effects
  const glitchChars = [
    '█', '▓', '▒', '░', '▚', '▟', '■', '□', '▪', '▫', '▢',
    'Æ', 'Ø', 'æ', 'ø', 'þ', 'ß', 'Þ', 'ð', 'Ð',
    '¦', '|', '/', '\\', '_', '=', '+', '-', '*',
    '҉', 'Д', '̸̛', '̷̢', '̵̡', '̴̢'
  ];
  
  // Ancient Greek characters for philosophical rewards
  const greekChars = [
    'α', 'β', 'γ', 'δ', 'ε', 'ζ', 'η', 'θ', 'ι', 'κ', 'λ', 'μ', 
    'ν', 'ξ', 'ο', 'π', 'ρ', 'σ', 'τ', 'υ', 'φ', 'χ', 'ψ', 'ω',
    'Α', 'Β', 'Γ', 'Δ', 'Ε', 'Ζ', 'Η', 'Θ', 'Ι', 'Κ', 'Λ', 'Μ', 
    'Ν', 'Ξ', 'Ο', 'Π', 'Ρ', 'Σ', 'Τ', 'Υ', 'Φ', 'Χ', 'Ψ', 'Ω'
  ];
  
  // Special characters to inject
  const specialGlitches = [
    '}SYSADMIN.OVERRIDE{', 
    '[DATA_CORRUPT]', 
    '<NULL>', 
    '#ERR0R', 
    '0x00:F0:42',
    '!BREACH:L3!',
    '$REDACTED$',
    'Ṽ̷̧̢̤̙̓̌͗E̵̲̾I̵̗̎̕L̷̩̞̊͑Ŕ̴̨̆I̷̬̐͝F̸̬̣̬̈́͘T̴̲̓̒̈́',
    '::VOID::',
    '--CIRCUIT--'
  ];
  
  // Apply corruptions
  let result = text.split('');
  
  // Make glitches very mild to keep text readable
  const actualSeverity = Math.min(severity, 0.1); // Cap severity to keep text readable
  
  // Replace only a few characters with glitch characters
  for (let i = 0; i < result.length; i++) {
    // Skip spaces and certain punctuation
    if (result[i] === ' ' || result[i] === '\n' || result[i] === '.' || result[i] === ',') continue;
    
    // Very low chance to replace characters to keep text readable
    if (Math.random() < actualSeverity * 0.2) {
      // Use regular glitch characters
      result[i] = glitchChars[Math.floor(Math.random() * glitchChars.length)];
    }
  }
  
  // Add very few special glitch text inserts to keep readability
  const insertCount = Math.floor(text.length * actualSeverity * 0.01); // Lower insert count
  for (let i = 0; i < insertCount; i++) {
    const insertPosition = Math.floor(Math.random() * result.length);
    const glitchText = specialGlitches[Math.floor(Math.random() * specialGlitches.length)];
    result.splice(insertPosition, 0, glitchText);
  }
  
  // Return the corrupted text
  return result.join('');
}