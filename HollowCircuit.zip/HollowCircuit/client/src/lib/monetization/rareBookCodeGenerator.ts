/**
 * Rare Book Code Generator - Veilrift: Fragments
 * 
 * This module handles the generation and display of extremely rare
 * book redemption codes that give players a chance to purchase one of
 * the limited physical copies of "The Hollow Circuit" collection.
 */

import { CircuitLayer } from '@/lib/stores/useGameState';

// Configuration for the rare book system
const BOOK_CONFIG = {
  // Odds of winning (1 in X players)
  odds: 100000,
  
  // Total books that will ever be available
  totalBooks: 10,
  
  // Books already claimed (would be tracked on server)
  claimedBooks: 0,
  
  // Minimum circuit layer requirement
  minLayer: 'core' as CircuitLayer,
  
  // Minimum philosophical choices required
  minPhilosophicalChoices: 15,
  
  // Minimum unique puzzles experienced
  minUniquePuzzles: 10
};

// Seed value that would be obtained from server in real implementation
const SERVER_SEED = '0xf7a8b13e94c6d2';

/**
 * Interface for tracking player eligibility
 */
export interface PlayerEligibility {
  deviceId: string;
  deepestLayer: CircuitLayer;
  philosophicalChoiceCount: number;
  uniquePuzzlesExperienced: number;
  hasCheckedForCodeToday: boolean;
  lastCheckTimestamp: number;
}

/**
 * Interface for a winning code
 */
export interface RareBookCode {
  id: string;
  code: string;
  dateGenerated: Date;
  expirationDate: Date;
  redemptionUrl: string;
}

/**
 * Get default player eligibility (would fetch from storage in real app)
 */
export function getInitialPlayerEligibility(): PlayerEligibility {
  // In a real implementation, this would be loaded from persistent storage
  // and would include a genuinely unique device ID
  return {
    deviceId: generatePseudoDeviceId(),
    deepestLayer: 'surface',
    philosophicalChoiceCount: 0,
    uniquePuzzlesExperienced: 0,
    hasCheckedForCodeToday: false,
    lastCheckTimestamp: 0
  };
}

/**
 * Generate a pseudo device ID (for demo)
 * In production, would use proper device fingerprinting
 */
function generatePseudoDeviceId(): string {
  const randomPart = Math.random().toString(36).substring(2, 15);
  const timestampPart = Date.now().toString(36);
  return `dev_${randomPart}${timestampPart}`;
}

/**
 * Update player eligibility based on game progress
 */
export function updatePlayerEligibility(
  currentEligibility: PlayerEligibility,
  currentLayer: CircuitLayer,
  newPhilosophicalChoice: boolean,
  currentPuzzleId: string
): PlayerEligibility {
  // Track deepest layer reached
  const deepestLayer = getLayerDepth(currentLayer) > getLayerDepth(currentEligibility.deepestLayer)
    ? currentLayer
    : currentEligibility.deepestLayer;
  
  // Count philosophical choices
  const philosophicalChoiceCount = newPhilosophicalChoice
    ? currentEligibility.philosophicalChoiceCount + 1
    : currentEligibility.philosophicalChoiceCount;
  
  // In a real implementation, we would track a set of unique puzzle IDs
  // For this prototype, we'll just increment a counter
  const uniquePuzzlesExperienced = currentEligibility.uniquePuzzlesExperienced + 1;
  
  // In a real implementation, we'd store these values persistently
  return {
    ...currentEligibility,
    deepestLayer,
    philosophicalChoiceCount,
    uniquePuzzlesExperienced
  };
}

/**
 * Check if a player is eligible for a rare book code
 */
export function checkRareBookEligibility(eligibility: PlayerEligibility): boolean {
  // Verify minimum requirements
  if (getLayerDepth(eligibility.deepestLayer) < getLayerDepth(BOOK_CONFIG.minLayer)) {
    return false;
  }
  
  if (eligibility.philosophicalChoiceCount < BOOK_CONFIG.minPhilosophicalChoices) {
    return false;
  }
  
  if (eligibility.uniquePuzzlesExperienced < BOOK_CONFIG.minUniquePuzzles) {
    return false;
  }
  
  // Check if we've already performed a check today
  const now = Date.now();
  const oneDayMs = 24 * 60 * 60 * 1000;
  if (eligibility.hasCheckedForCodeToday && 
      now - eligibility.lastCheckTimestamp < oneDayMs) {
    return false;
  }
  
  // Determine remaining books
  const remainingBooks = BOOK_CONFIG.totalBooks - BOOK_CONFIG.claimedBooks;
  if (remainingBooks <= 0) {
    return false;
  }
  
  // In a real implementation, this would be a secure server-side calculation
  // This is a simulation for demonstration purposes only
  const pseudoRandom = generatePseudoRandom(eligibility.deviceId, SERVER_SEED);
  const winThreshold = 1 / BOOK_CONFIG.odds;
  
  // Simulate odds calculation
  return pseudoRandom < winThreshold;
}

/**
 * Generate a winning code
 */
export function generateWinningCode(eligibility: PlayerEligibility): RareBookCode {
  // In a real implementation, this would happen server-side
  const codeId = `HOLLOW-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
  
  // Generate a code pattern: VEIL-XXXX-XXXX-XXXX
  const part1 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const part2 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const part3 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const code = `VEIL-${part1}-${part2}-${part3}`;
  
  // Set expiration 30 days from now
  const expirationDate = new Date();
  expirationDate.setDate(expirationDate.getDate() + 30);
  
  return {
    id: codeId,
    code,
    dateGenerated: new Date(),
    expirationDate,
    redemptionUrl: `https://hollowcircuit.com/redeem?code=${code}`
  };
}

/**
 * Get the depth value of a layer
 */
function getLayerDepth(layer: CircuitLayer): number {
  switch(layer) {
    case 'surface': return 1;
    case 'middle': return 2;
    case 'deep': return 3;
    case 'core': return 4;
    default: return 0;
  }
}

/**
 * Generate a pseudo-random number between 0 and 1
 * In a real implementation, this would be a cryptographically secure
 * operation performed server-side.
 */
function generatePseudoRandom(deviceId: string, seed: string): number {
  const combined = deviceId + seed + Date.now().toString();
  let hash = 0;
  
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  // Normalize to 0-1 range
  return Math.abs(hash) / 2147483647;
}