import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { useGameState } from "./lib/stores/useGameState";
import { GameRenderer } from "./components/game/GameRenderer";
import { AudioController } from "./components/game/AudioController";
import { GlitchEffect } from "./components/game/GlitchEffect";
import { InterfaceLayer } from "./components/ui/InterfaceLayer";
import { TutorialOverlay } from "./components/ui/TutorialOverlay";
import { Button } from "./components/ui/button";
import { cn } from "./lib/utils";
import { generateRandomStartupSequence, StartupSequence } from "./lib/content/startupSequences";
import { corruptText } from "./lib/effects/visualGlitches";
import "@fontsource/inter";

// Define the startup context to be shared across components
function useStartupSequence() {
  const [sequence] = useState<StartupSequence>(() => generateRandomStartupSequence());
  return sequence;
}

function LoadingScreen() {
  const sequence = useStartupSequence();
  const [progressWidth, setProgressWidth] = useState(0);
  
  // Animate the loading bar
  useEffect(() => {
    const interval = setInterval(() => {
      setProgressWidth(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return prev;
        }
        return prev + Math.random() * 10;
      });
    }, 200);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-black text-white z-50">
      <div className="text-4xl font-mono mb-8">{sequence.title}</div>
      <div className="w-64 h-1 bg-gray-800 relative overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-white"
          style={{ width: `${progressWidth}%` }}
        ></div>
      </div>
      <div className="mt-4 text-xs text-gray-400 font-mono">{sequence.loadingText}</div>
      
      {/* Occasional system messages that flash briefly */}
      {Math.random() < 0.3 && (
        <div className="mt-6 text-[10px] font-mono text-gray-600 animate-pulse max-w-xs text-center">
          {corruptText(`SYSTEM: Node integrity at ${Math.floor(Math.random() * 100)}%. Protocol ${Math.floor(Math.random() * 999)} active.`, 0.1)}
        </div>
      )}
    </div>
  );
}

function IntroScreen({ onStart }: { onStart: () => void }) {
  const sequence = useStartupSequence();
  const [glitched, setGlitched] = useState(false);
  
  // Occasionally glitch the text
  useEffect(() => {
    const interval = setInterval(() => {
      setGlitched(true);
      setTimeout(() => setGlitched(false), 100);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-black text-white z-50 p-4">
      <div className={cn(
        "text-4xl font-mono mb-8",
        glitched ? "glitch-text" : ""
      )}>
        {sequence.title}
      </div>
      <div className="max-w-lg text-center mb-8">
        {sequence.introText.map((paragraph, index) => (
          <p key={index} className={index === 0 ? "mb-4" : "mb-2"}>
            {glitched ? corruptText(paragraph, 0.2) : paragraph}
          </p>
        ))}
        <p className="text-sm text-gray-400 mt-4 font-mono">
          {sequence.quote}
        </p>
      </div>
      <Button
        variant="outline"
        onClick={onStart}
        className="border-white text-white hover:bg-white hover:text-black transition-all"
      >
        {sequence.buttonText}
      </Button>
    </div>
  );
}

function App() {
  const [loading, setLoading] = useState(true);
  const [showIntro, setShowIntro] = useState(true);
  const { initGame, currentPhase } = useGameState();

  // Simulate loading time
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Initialize game when starting
  const handleStart = () => {
    setShowIntro(false);
    initGame();
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div 
        className={cn(
          "w-full h-screen bg-black text-white overflow-hidden",
          "font-mono"
        )}
      >
        {loading ? (
          <LoadingScreen />
        ) : showIntro ? (
          <IntroScreen onStart={handleStart} />
        ) : (
          <>
            <AudioController />
            <GlitchEffect />
            {/* Tutorial Overlay */}
            <TutorialOverlay />
            
            {/* Direct rendering of game interface */}
            <InterfaceLayer />
            
            {/* 3D Canvas */}
            <Canvas
              shadows
              camera={{
                position: [0, 0, 5],
                fov: 45,
              }}
              gl={{
                antialias: true,
                alpha: true,
              }}
              className="canvas-container"
            >
              <color attach="background" args={["#000000"]} />
              <ambientLight intensity={0.2} />
              <directionalLight position={[0, 10, 5]} intensity={0.5} />
              
              <Suspense fallback={null}>
                <GameRenderer />
              </Suspense>
            </Canvas>
          </>
        )}
      </div>
    </QueryClientProvider>
  );
}

export default App;
