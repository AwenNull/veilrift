import { useState, useEffect } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { 
  PlayerEligibility, 
  RareBookCode,
  getInitialPlayerEligibility,
  updatePlayerEligibility,
  checkRareBookEligibility,
  generateWinningCode
} from '@/lib/monetization/rareBookCodeGenerator';

/**
 * Custom hook to manage rare book eligibility checking and code generation
 * This would be integrated with native app purchase verification in production
 */
export function useRareBookEligibility() {
  // State for tracking player eligibility
  const [playerEligibility, setPlayerEligibility] = useState<PlayerEligibility>(
    getInitialPlayerEligibility()
  );
  
  // State for winning code (if generated)
  const [winningCode, setWinningCode] = useState<RareBookCode | null>(null);
  
  // State for controlling the display modal
  const [showCodeModal, setShowCodeModal] = useState(false);
  
  // Access game state for eligibility tracking
  const { 
    currentLayer, 
    playerPath, 
    availablePuzzles, 
    currentPuzzleIndex, 
    decisions 
  } = useGameState();
  
  // Update player eligibility when game state changes
  useEffect(() => {
    // Skip if no decisions have been made yet
    if (decisions.length === 0) return;
    
    // Get current puzzle if available
    const currentPuzzle = availablePuzzles[currentPuzzleIndex % availablePuzzles.length];
    if (!currentPuzzle) return;
    
    // Determine if the last decision was philosophical in nature
    // This is a simple check - in a real implementation, we would have more sophisticated detection
    const lastDecision = decisions[decisions.length - 1];
    const isPhilosophical = 
      lastDecision.toLowerCase().includes('consciousness') ||
      lastDecision.toLowerCase().includes('ontolog') ||
      lastDecision.toLowerCase().includes('ethic') ||
      lastDecision.toLowerCase().includes('paradox');
    
    // Update player eligibility
    const updatedEligibility = updatePlayerEligibility(
      playerEligibility,
      currentLayer,
      isPhilosophical,
      currentPuzzle.id
    );
    
    setPlayerEligibility(updatedEligibility);
    
    // Check if player is eligible for a rare book code
    if (checkRareBookEligibility(updatedEligibility)) {
      // Generate winning code
      const code = generateWinningCode(updatedEligibility);
      setWinningCode(code);
      setShowCodeModal(true);
      
      // Mark that we've checked today (to prevent multiple checks)
      setPlayerEligibility(prev => ({
        ...prev,
        hasCheckedForCodeToday: true,
        lastCheckTimestamp: Date.now()
      }));
      
      // Log for debugging
      console.log('Congratulations! Rare book code generated:', code);
    }
  }, [decisions.length, currentLayer]);
  
  // Function to close the modal
  const closeCodeModal = () => {
    setShowCodeModal(false);
  };
  
  // Debug function to force generate a code (only for development)
  const debugGenerateCode = () => {
    const code = generateWinningCode(playerEligibility);
    setWinningCode(code);
    setShowCodeModal(true);
  };
  
  return {
    playerEligibility,
    winningCode,
    showCodeModal,
    closeCodeModal,
    debugGenerateCode
  };
}