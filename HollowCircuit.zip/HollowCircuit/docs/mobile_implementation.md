# Mobile Implementation for Veilrift: Fragments

## Technical Requirements for iOS/Android App

### Development Framework
- **React Native**: Leverage existing React codebase for cross-platform development
- **Expo**: Simplify builds and deployment across platforms
- **Three.js for React Native**: Port existing Three.js visuals

### Mobile-Specific Adaptations

#### UI/UX Modifications
- Touch-optimized interface
- Device-responsive layout for varying screen sizes
- Haptic feedback for key interactions

#### Performance Optimizations
- Simplified 3D rendering for mobile GPUs
- Asset loading strategy for limited bandwidth
- Memory management for restricted resources

### Store Presence Setup

#### App Store (iOS)
- Developer account registration ($99/year)
- App Store Connect configuration
- App Review Guidelines compliance

#### Google Play Store (Android)
- Developer account registration ($25 one-time)
- Play Console setup
- Content rating requirements

### Purchase Implementation

#### In-App Purchase Integration
- **StoreKit** for iOS
- **Google Play Billing** for Android
- Purchase receipt validation (server-side)
- Restore purchase functionality

#### Security Measures
- Obfuscation of app code
- Anti-piracy measures
- Server-side verification of purchases

## Rare Book Award System

### Code Generation Architecture
- Secure, server-side random code generation
- Non-guessable codes with validation
- Tamper-proof claim mechanism

### Player Eligibility System
- Complete game state tracking
- Achievement system for progress milestones
- Random selection algorithm (1:100,000 odds)
- Unique device/account verification

### Code Redemption Process
- Secure API for code validation
- User information collection for fulfillment
- Email verification process
- Shipping details confirmation

### Fulfillment Backend
- Database of awarded codes
- Admin panel for tracking claimed codes
- Integration with printing/fulfillment service
- Shipping status updates

## Data Structure for Code Generation

```typescript
interface RareBookCode {
  id: string;             // Unique identifier
  code: string;           // Actual redemption code
  dateGenerated: Date;    // When the code was created
  playerDeviceId: string; // Unique device identifier
  playerPath: string[];   // The philosophical path taken
  claimed: boolean;       // Whether code has been claimed
  claimDate?: Date;       // When code was claimed
  recipientInfo?: {       // Info collected at redemption
    name: string;
    email: string;
    shippingAddress: string;
    contactPhone: string;
  }
}
```

## Monetization Technical Architecture

### One-Time Purchase Flow
1. App downloaded from store (free or with upfront cost)
2. Payment processing through platform payment system
3. Receipt verification through secure server
4. App unlocks full functionality
5. Purchase state persisted in secure storage

### Book Award Eligibility Logic

```typescript
function checkRareBookEligibility(player: PlayerState): boolean {
  // Only check if player has completed core game requirements
  if (!hasCompletedEssentialPath(player)) return false;
  
  // Random chance (1:100,000)
  const randomValue = secureRandomNumber(0, 100000);
  
  // Actual odds determined by available books remaining
  const booksRemaining = getRemainingBooksCount();
  const totalOdds = booksRemaining > 0 ? 1 : 0;
  
  return randomValue < totalOdds;
}
```

## UI Implementation for Code Redemption

- Modal dialog for code display with celebration animation
- Clear instructions for redemption
- Copy-to-clipboard functionality
- Direct link to redemption website
- Email option to send code to player